# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 09:36:49 2022

@author: Developer
"""

from osmnx import distance, utils_graph
from networkx import shortest_path
from class_objects import Bus, Trip, Route


def GenerateRouting(G, modelData, modelConfig, modelParameters, modify_list):
    
    max_distance = modelConfig.THRESHOLD_RADIUS_BUS_STOP
    print('...Calculating routes between population nodes and bus stops')
    neighborhood_distance_matrix = GetDistance(G, modelData.Population, modelData.Stops)
    
    print('...Assigning bus stops based on distance threshold (%d km)' % max_distance)
    # Assign populations to bus stops (1:1) based on shortest distance...
    walkroute_matrix, NEW_STOPS, ASSIGNMENTS = AssignBusStops(modelConfig, modelData,
                                                              neighborhood_distance_matrix,
                                                              max_distance)
    modelParameters.ASSIGNMENTS = ASSIGNMENTS
    modelParameters.walkroute_matrix = walkroute_matrix
    # If distance threshold rule yielded new "bus stops"
    # (i.e., population nodes that were converted to pickup points)
    # then add these to the distance/route matrix.
    added_stops = {}
    for ns in NEW_STOPS:
        if not ns in modelData.Stops.keys():
            added_stops[ns] = NEW_STOPS[ns]
    modelData.Stops = modelData.Stops | added_stops
    
    print('...Computing bus routes')
    # Calculate bus routes and combine with neighborhood routes
    bus_distance_matrix = GetDistance(G, modelData.Shelters, modelData.Stops)
    distance_matrix = bus_distance_matrix | neighborhood_distance_matrix
    modelParameters.distance_matrix = distance_matrix
    
    
    
    
    #GenerateBusNetwork2(modelConfig, modelData, modelParameters)
    
    #print('...Generating bus network')
    #GenerateBusNetwork(modelConfig, modelData, modelParameters, modify_list)
    
    # Generate list of routes from population nodes to bus stops
    #route_list, dictWalkTimes = BuildRoutes(G, modelData, modelParameters)
        
    #modelParameters.dictWalkTimes = dictWalkTimes
    
    #return route_list
    

def GenerateBusNetwork2(modelConfig, modelData, modelParameters):
    
    for k in modelData.BUS.keys():
        print(k)
    

def ModifyBusNetwork(BUS, BUSROUTES, route_id, xAction, xAmount):
    
    if xAction == 'add':
        
        last_id = len(BUS)
        for x in range(1, xAmount+1):
            new_id = str(last_id + x)
            BUS['B'+new_id] = ['Bus'+new_id, route_id, 9999]
            
        
        
        
    return BUS, BUSROUTES
    
def GenerateBusNetwork(modelConfig, modelData, modelParameters, modify_list):
    BUSROUTES = {}
    BUS = {}
    x = 1
    y = 1
    iBus = 1
    for k in modelData.Stops.keys():
        minVal = 99999
        minValKey = ''
        minValRoute = ''
        
        # Now add routes for all stop-shelter pairs in case bus routes
        # change during the simulation
        for j in modelData.Shelters.keys():
                
            route_id = "R" + str(x)
            unique_name = "Route " + str(x)
            
            # Search for closest Tier 1 shelter
            if modelConfig.TIERED_EVACUATION == True:
                tier = modelData.Shelters[j].Tier
            else:
                tier = 0
            computed_distance = modelParameters.distance_matrix[k, j][0]
            if computed_distance < minVal and tier <= 1:
                minVal = computed_distance
                #minValKey = j
                minValRoute = route_id
                
            origin = j
            destination = k
            
            leg_identifier = "L" + str(y)
            y += 1
            temp_list1 = [unique_name, origin, destination, route_id, 1, 'Pickup']
            BUSROUTES[leg_identifier] = temp_list1
            
            leg_identifier = "L" + str(y)
            y += 1
            temp_list2 = [unique_name, destination, origin, route_id, 2, 'Drop']
            BUSROUTES[leg_identifier] = temp_list2
            
            x += 1

        # Create BUS with route assignment
        bus_id = "B" + str(iBus)
        bus_name = "Bus" + str(iBus)
        bus_capacity = modelConfig.BUS_CAPACITY
        
        # Assign bus to Tier 1 closest shelter route
        #origin = minValKey # closest shelter
        #destination = k # bus stop
        bus_route = minValRoute # route associated with closest shelter
        BUS[bus_id] = [bus_name, bus_route, bus_capacity]
        iBus += 1
    
    for sh1 in modelData.Shelters.keys():
        for sh2 in modelData.Shelters.keys():
            if not sh1 == sh2:
                route_id = "R" + str(x)
                unique_name = "Route " + str(x)
                
                leg_identifier = "L" + str(y)
                y += 1
                temp_list1 = [unique_name, sh1, sh2, route_id, 1, 'Transfer']
                BUSROUTES[leg_identifier] = temp_list1
                
    if len(modify_list) > 0:
        for r in modify_list:
            BUS, BUSROUTES = ModifyBusNetwork(BUS, BUSROUTES, r, 'add', 1)
        
    modelParameters.BUS = BUS
    modelParameters.BUSROUTES = BUSROUTES
    


def GetDistance(G, origin, destination):
    a = iterate_pairs(G, origin, destination)
    b = iterate_pairs(G, origin, origin)
    return a | b
    
def iterate_pairs(G, dict1, dict2):
    
    distance_matrix = {}
    for p in dict1.keys():
        start_lat = dict1[p].Latitude
        start_lon = dict1[p].Longitude
        
        for s in dict2.keys():
            end_lat = dict2[s].Latitude
            end_lon = dict2[s].Longitude
            
            if (p,s) not in distance_matrix.keys():
                start_node = distance.nearest_nodes(G, start_lon, start_lat)
                end_node = distance.nearest_nodes(G, end_lon, end_lat)
                
                #ASSUME SPEED AND TIME EQUAL BOTH WAYS
                distance_matrix[p, s] = calculate_distance(G, start_node, end_node)
                distance_matrix[s, p] = calculate_distance(G, start_node, end_node)
    
    return distance_matrix

def calculate_distance(G, start_node, end_node):
    
    route = shortest_path(G, start_node, end_node, weight='length')
    d = int(sum(utils_graph.get_route_edge_attributes(G, route, "length")))
    t = int(sum(utils_graph.get_route_edge_attributes(G, route, "travel_time")))
    d = round(d/1000, 2)
    t = round(t/60, 2)
    if t == 0:
        speed = 0
    else:
        speed = round(d/(t/60), 2)
    routeParams = (d, t, speed)
    
    return routeParams


def AssignBusStops(modelConfig, modelData, distance_matrix, WALK_THRESHOLD):
    walkroute_matrix = {}
    NEW_STOPS = {}
    ASSIGNMENTS = {}
    for n in modelData.Population.keys():
        minDistance = 999999
        selectedStop = 'BLANK_KEY'
        for s in modelData.Stops.keys():
            if distance_matrix[n, s][0] < minDistance and distance_matrix[n, s][0] > 0:
                minDistance = distance_matrix[n, s][0]
                selectedStop = s
        if minDistance > WALK_THRESHOLD:
            recommendation = 'Add bus stop here.'
            walkroute_matrix[n] = (n, 0, recommendation)
            if not n in NEW_STOPS:
                NEW_STOPS[n] = modelData.Population[n]
        else:
            recommendation = 'Use bus stop ' + str(selectedStop) + '.'
            walkroute_matrix[n] = (selectedStop, minDistance, recommendation)
            if not selectedStop in NEW_STOPS:
                NEW_STOPS[selectedStop] = modelData.Stops[selectedStop]
        
    # Make revised list of neighborhoods that each NEW_STOP supports
    for s in NEW_STOPS.keys():
        ASSIGNMENTS[s] = []
        for n in modelData.Population.keys():
            if walkroute_matrix[n][0] == s:
                ASSIGNMENTS[s].append(n)
                
    for s in modelData.Stops:
        if not s in ASSIGNMENTS.keys():
            ASSIGNMENTS[s] = []
    
    
    return walkroute_matrix, NEW_STOPS, ASSIGNMENTS


def BuildRoutes(G, modelData, modelParameters):
    
    NODES = modelData.Stops | modelData.Shelters
    BUS = modelParameters.BUS
    BUSROUTES = modelParameters.BUSROUTES
    
    walkroute_matrix = modelParameters.walkroute_matrix
    
    dictWalkTimes = {}
    #route_list = []
    route_list = {}
    #route_d = []
    #route_t = []
    for n in modelData.Population.keys():
        orig_lat = (modelData.Population[n].Latitude)
        orig_lon = (modelData.Population[n].Longitude)
        orig_node = distance.nearest_nodes(G, orig_lon, orig_lat)
        
        assigned_stop = walkroute_matrix[n][0]
        dest_lat = NODES[assigned_stop].Latitude
        dest_lon = NODES[assigned_stop].Longitude
        dest_node = distance.nearest_nodes(G, dest_lon, dest_lat)
        route = shortest_path(G, orig_node, dest_node, weight='length')
        d = modelParameters.distance_matrix[n, assigned_stop][0] # km
        t = modelParameters.distance_matrix[n, assigned_stop][1] # minutes
        route_list[n] = route
        #route_list.append(route)
        #route_d.append(d)
        #route_t.append(t)
        dictWalkTimes[n] = [t, assigned_stop]
    
    dr=1
    for b in BUS.keys():
        list_of_nodes = BUSROUTES[BUS[b][2]].Nodes
        N = len(list_of_nodes)
        for i in range(0,N):
            route_id = 'display_route_' + str(dr) + "_" +  str(BUS[b][2])
            dr += 1
            current_node = list_of_nodes[i]
            if i < N-1:
                next_node = list_of_nodes[i+1]
            else:
                next_node = list_of_nodes[0]
            
            orig_lat = (NODES[current_node].Latitude)
            orig_lon = (NODES[current_node].Longitude)
            orig_node = distance.nearest_nodes(G, orig_lon, orig_lat)
            
            dest_lat = (NODES[next_node].Latitude)
            dest_lon = (NODES[next_node].Longitude)
            dest_node = distance.nearest_nodes(G, dest_lon, dest_lat)
            route = shortest_path(G, orig_node, dest_node, weight='length')
            #route_list.append(route)
            route_list[route_id] = route
        
    
    modelParameters.dictWalkTimes = dictWalkTimes
    
    return route_list, dictWalkTimes
    
    
def CalculateDemand(modelData, modelParameters, modelConfig):
    demand = {s: 0 for s in modelData.Stops.keys()}
    distance_demand = {s: 0 for s in modelData.Stops.keys()}
    distance = {s: 0 for s in modelData.Stops.keys()}
    
    
    for s in modelData.Stops:
        # FIND N
        minDistanceToOtherAvailableShelter = 9999
        bestOption = 'None'
        for sh in modelData.Shelters.keys():
            dist_to_shelter = modelParameters.distance_matrix[s, sh][0]
            
            buscap = modelConfig.ADJUSTED_BUS_CAPACITY
            CLEARANCE_TIME_OBJECTIVE = modelConfig.ARRIVAL_WINDOW
            fixed_time = buscap * modelConfig.TIME_PER_AGENT_LOAD_BUS
            transit_time = modelParameters.distance_matrix[s, sh][1]
            
            MAXCAP = (buscap * CLEARANCE_TIME_OBJECTIVE) / (2 * (fixed_time + transit_time))
            
            
            if dist_to_shelter < minDistanceToOtherAvailableShelter and modelData.Shelters[sh].Tier == 1:
                minDistanceToOtherAvailableShelter = dist_to_shelter
                bestOption = sh
        
        for n in modelParameters.ASSIGNMENTS[s]:
            demand[s] += modelData.Population[n].NumPeople
            
        distance[s] = modelParameters.distance_matrix[bestOption,s][1]
        distance_demand[s] = distance[s] * demand[s]
        
        #if demand[s] > MAXCAP:
        #print('%s demand (%s), recommended amount %d.' % (s, demand[s], MAXCAP))
    
    return demand




