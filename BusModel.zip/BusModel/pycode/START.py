# -*- coding: utf-8 -*-
"""
Created on Wed Apr  6 09:14:44 2022

@author: GMU
"""

from class_objects import Inputs
from datetime import datetime
from os import path, mkdir


def Configure_Inputs():
    
    modelConfig = Inputs
    
    ############ SET SIMULATED START TIME ############
    yyyy = 2022 # Calendar year 2022
    mm = 6      # June
    dd = 1      # 1st day of the month
    hh = 7      # 7:00AM
    start_time = datetime(yyyy, mm, dd, hh, 0, 0, 0)
    modelConfig.START_TIME = start_time
    ##################################################
    
    ################ SIMULATION DESIGN ###############
    modelConfig.NUMBER_OF_EXPERIMENTS = 10
    modelConfig.SIMULATION_TIME = 80*60 # max simulation time cutoff (minutes)
    
    ### CHOOSE SIMULATION METHOD ###
    # AddBusToRouteWithMaxWait: 1. Use starting number of buses as initial solution
    #                           2. Initial routing plan will not change as new buses
    #                              are added!
    #                           3. Add buses to max wait time route after sims run
    # UseCapacitatedFacilityAllocation: Same as above except with capacitated
    #                                   facility allocation heuristic governing
    #                                   routing plan, instead of simply choosing
    #                                   nearest-neighbor pickups and shelters.
    # QuickTestRun: Does not add buses iteratively (takes lots of time), but
    #               instead uses the calibration algorithm to quickly "jump" to the
    #               right number of buses. Doesn't necessarily generate "good"
    #               results.
    mymethod = 'AddBusToRouteWithMaxWait'
    #mymethod = 'UseCapacitatedFacilityAllocation'
    #mymethod = 'QuickTestRun'
    modelConfig.SOLVE_METHOD = mymethod
    ##################################################
    
    ################# SCENARIO DESIGN ################
    modelConfig.PERCENTAGE_POPULATION_TO_SHELTER = 0.80 * 0.08
    ##modelConfig.NUMBER_OF_BUSES = 20
    modelConfig.MIN_NUMBER_BUSES = 20 # Initial number of buses
    modelConfig.MAX_NUMBER_BUSES = 50 # Max number of buses
    modelConfig.ZONES_TO_EVACUATE = ['B'] # must be list object
    modelConfig.SELECT_NODES_TO_EVACUATE = []
    modelConfig.THRESHOLD_RADIUS_BUS_STOP = 0 # km
    modelConfig.BUS_CAPACITY = 20 # individual people
    modelConfig.PEOPLE_PER_AGENT = 2 # individuals per model agent 'Evacuee'
    modelConfig.TIME_PER_AGENT_LOAD_BUS = 0.5 # minutes to load one agent onto bus
    modelConfig.TIME_PER_WHEELCHAIR_LOAD = 4 # minutes to load wheelchair
    modelConfig.PERCENT_IN_WHEELCHAIR = 0.29
    modelConfig.BUS_MIN_INTERVAL = 10 # min time spent idling (if multiple buses on same route)
    modelConfig.BUS_MAX_INTERVAL = 30 # max time spent idling at pickup
    modelConfig.TIERED_EVACUATION = True
    modelConfig.ARRIVAL_WINDOW = 4*60 # key parameter for arrival distribution
    ##################################################
    
    
    modelConfig.NEIGHBORHOOD_ROUTE_COLOR = '#fa4d4d' # red
    modelConfig.BUS_ROUTE_COLOR = '#4b9dfa' # blue
    
    modelConfig.INPUT_FILE_NAME = 'model_inputs.xlsx'
    dir_inputs = 'data'
    dir_outputs = 'output'

    modelConfig.INPUT_DIRECTORY = path.join(path.realpath('../'), dir_inputs)
    modelConfig.OUTPUT_DIRECTORY = path.join(path.realpath('../'), dir_outputs)
    
    # If no output folder exists, make one
    if not path.exists(modelConfig.OUTPUT_DIRECTORY):
        mkdir(modelConfig.OUTPUT_DIRECTORY)
        
    #ac = modelConfig.BUS_CAPACITY / modelConfig.PEOPLE_PER_AGENT
    iter_amount = 1
    while iter_amount * modelConfig.PEOPLE_PER_AGENT <= modelConfig.BUS_CAPACITY:
        iter_amount += 1
    modelConfig.ADJUSTED_BUS_CAPACITY = iter_amount-1
    
    return modelConfig