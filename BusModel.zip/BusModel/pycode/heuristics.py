# -*- coding: utf-8 -*-
"""
Created on Thu Apr 21 12:30:57 2022

@author: Developer
"""
from class_objects import Route, Trip, Transfer

def FacilityAllocation(ALLOCATE_DEMAND, transit_cost, current_shelter_availability, adjusted_capacity):
    
    PPA = 2
    
    TABU = []
    SOLUTIONS = {}
    VALUE = {}
    #assignment_costs = {(s,sh): ALLOCATE_DEMAND[s, sh] * transit_cost[s, sh] for (s,sh) in ALLOCATE_DEMAND.keys() if ALLOCATE_DEMAND[s,sh] > 0}
    total_work_cost = 0
    t = 0
    improvement = 0
    best_solution = 0
    stall_time = 0
    attempts = 0
    while t < 200 and stall_time < 10:
        
        relative_cost = {}
        trade_amount = {}
        
        # SEARCH ALL USED DEMAND CHANNELS BETWEEN SHELTERS AND PICKUPS
        for v in [k for k in ALLOCATE_DEMAND.keys() if ALLOCATE_DEMAND[k] > 0]:
            #most_costly_assignment = max(assignment_costs, key=assignment_costs.get)
            s0 = v[0] # currently chosen pickup
            sh0 = v[1] # currently chosen shelter
            
            # SEARCH OUT OF ALL POSSIBLE SHELTER-PICKUP LINKS
            for (s,sh) in ALLOCATE_DEMAND.keys():
                
                # LINKS SAME PICKUP TO DIFFERENT SHELTER
                if s == s0 and sh != sh0:
                    # Re-route demand to a different shelter
                    # 1. Shelter has available space
                    if current_shelter_availability[sh] >= PPA:
                        
                        # What is the amount of demand that would be traded
                        maxtrade = min(ALLOCATE_DEMAND[s0,sh0]*PPA, current_shelter_availability[sh])
                        
                        if maxtrade == current_shelter_availability[sh]:
                            iter_amount = 0
                            while iter_amount * PPA < current_shelter_availability[sh]:
                                iter_amount += 1
                            if current_shelter_availability[sh] % PPA == 0:
                                maxtrade = iter_amount
                            else:
                                maxtrade = iter_amount-1
                        else:
                            maxtrade = ALLOCATE_DEMAND[s0,sh0]
                            
                        # MODIFICATION: MUST TRADE ALL OF DEMAND OR NOTHING
                        if maxtrade == ALLOCATE_DEMAND[s0,sh0]:
                            trade_amount[s0, sh0, s, sh] = maxtrade
                            cost1 = trade_amount[s0, sh0, s, sh] * transit_cost[s, sh]
                            cost0 = ALLOCATE_DEMAND[s0, sh0] * transit_cost[s0, sh0]
                            relative_cost[s0, sh0, s,sh] = cost1 - cost0 # gain of trading
                            
                    # 2. Shelter is full (but has room for trade)
                    elif current_shelter_availability[sh] < PPA and adjusted_capacity[sh] >= PPA:
                        
                        # List other nodes that connect to shelter 'sh'
                        temp_dict = {}
                        for (sN,shN) in ALLOCATE_DEMAND.keys():
                            if shN == sh:
                                temp_dict[sN, shN] = ALLOCATE_DEMAND[sN, shN]
                        
                        # For every other node, record the trade amount and relative cost
                        for k in temp_dict.keys():
                            #kN = temp_dict[k]
                            maxtrade = min(ALLOCATE_DEMAND[s0, sh0]*PPA, ALLOCATE_DEMAND[k[0],k[1]]*PPA, current_shelter_availability[k[1]])
                            
                            if maxtrade == current_shelter_availability[k[1]]:
                                iter_amount = 0
                                while iter_amount * PPA < current_shelter_availability[k[1]]:
                                    iter_amount += 1
                                if current_shelter_availability[k[1]] % PPA == 0:
                                    maxtrade = iter_amount
                                else:
                                    maxtrade = iter_amount-1
                            else:
                                maxtrade = maxtrade/PPA
                                
                            if maxtrade == ALLOCATE_DEMAND[s0, sh0]:
                                trade_amount[s0, sh0, k[0], k[1]] = maxtrade
                                cost1 = trade_amount[s0, sh0, k[0], k[1]] * transit_cost[k[0], k[1]]
                                cost0 = ALLOCATE_DEMAND[s0, sh0] * transit_cost[s0, sh0]
                                relative_cost[s0, sh0, k[0], k[1]] = cost1 - cost0 # gain of trading
                    
                    
                #elif s != s0 and sh != sh0:
                #    # Re-route pair of demands to different shelters
                #    # Shelter 1 has available space
                #    # Shelter 2 has available space
                #    temp_dict = {}
                #    for (sN,shN) in ALLOCATE_DEMAND.keys():
                        
                    
        solfound = False
        attempts = 0
        feasible_trades = {k: relative_cost[k] for k in trade_amount.keys() if trade_amount[k] > 0 and k not in TABU}
        
        
        #print('# feasible trades = %d' % len(feasible_trades))
        if len(feasible_trades) > 0:
    
            chosen_trade = min(feasible_trades, key=feasible_trades.get)
            s0 = chosen_trade[0]
            sh0 = chosen_trade[1]
            s1 = chosen_trade[2]
            sh1 = chosen_trade[3]
            
            if trade_amount[s0, sh0, s1, sh1] == ALLOCATE_DEMAND[s0, sh0]:
                #print('trade amount: %d' % trade_amount[s0, sh0, s1, sh1])
                ALLOCATE_DEMAND[s0, sh0] -= trade_amount[s0, sh0, s1, sh1]
                current_shelter_availability[sh0] += trade_amount[s0, sh0, s1, sh1] * PPA
                ALLOCATE_DEMAND[s1, sh1] += trade_amount[s0, sh0, s1, sh1]
                current_shelter_availability[sh1] -= trade_amount[s0, sh0, s1, sh1] * PPA
                #assignment_costs = {(s,sh): ALLOCATE_DEMAND[s, sh] * transit_cost[s, sh] for (s,sh) in ALLOCATE_DEMAND.keys() if ALLOCATE_DEMAND[s,sh] > 0}
            else:
                TABU.append(chosen_trade)
        else:
            print('No feasible trades exist.')
            
        total_work_cost = 0
        for (s,sh) in ALLOCATE_DEMAND.keys():
            total_work_cost += ALLOCATE_DEMAND[s, sh] * transit_cost[s, sh]
        print(total_work_cost)
            
        SOLUTIONS[t] = [ALLOCATE_DEMAND, current_shelter_availability]
        VALUE[t] = total_work_cost
        best_solution = min(VALUE, key=VALUE.get)
        if VALUE[t] >= VALUE[best_solution]:
            stall_time += 1
        t += 1
        
    print('Best solution: %d' % VALUE[best_solution])
    ALLOCATE_DEMAND, current_shelter_availability = SOLUTIONS[best_solution]
    
    return ALLOCATE_DEMAND, current_shelter_availability
    
    
    
    
def InitializeFacilityCapacity(modelConfig, modelData, pickup_demand, initial_occupancy, MODE_UNKNOWN_DEMAND):
    
    # This sub-routine opens only the shelter tiers necessary to support demand
    max_tier = 1
    tier_capacity = -1
    demand_to_satisfy = sum(pickup_demand.values()) * modelConfig.PEOPLE_PER_AGENT
    while tier_capacity < 0 and max_tier <= 3:
        list_of_shelters = []
        list_of_capacity = []
        running_capacity = 0
        for sh in modelData.Shelters.keys():
            # Open tiers iteratively, assessing remaining capacity
            # and whether it is sufficient to handle total demand
            if modelData.Shelters[sh].Tier <= max_tier:
                list_of_shelters.append(sh)
                adj_capacity = modelData.Shelters[sh].Capacity - initial_occupancy[sh]
                list_of_capacity.append(adj_capacity)
                running_capacity += adj_capacity
                
        # TRIGGER: if demand > capacity, then tier_capacity < 0
        tier_capacity = sum(list_of_capacity) - demand_to_satisfy
        max_tier += 1
    if tier_capacity < 0:
        print('Error. Total shelter capacity exceeded.')
    
    if MODE_UNKNOWN_DEMAND == True:
        list_of_shelters = []
        for sh in modelData.Shelters.keys():
            list_of_shelters.append(sh)
    
    adjusted_capacity = {}
    remaining_capacity = {}
    for sh in list_of_shelters:
        adjusted_capacity[sh] = modelData.Shelters[sh].Capacity - initial_occupancy[sh]
        remaining_capacity[sh] = adjusted_capacity[sh]
    
    # Return: list of used shelters and initial remaining capacity
    return list_of_shelters, adjusted_capacity, remaining_capacity
    
    
    
def FacilityInitialSolution(modelData, modelParameters, list_of_pickups, list_of_shelters, pickup_demand_remaining, adjusted_capacity, remaining_capacity, MODE_UNKNOWN_DEMAND):  

    
    PPA = 2
    # CALCULATE TRANSIT COSTS FOR ALL SHELTERS AND ASSIGNED PICKUPS
    metric = 1 # 0=distance, 1=time
    ALLOCATE_DEMAND = {}
    transit_cost = {}
    for s1 in list_of_pickups:
        for sh in list_of_shelters:
            ALLOCATE_DEMAND[s1, sh] = 0
            transit_cost[s1, sh] = modelParameters.distance_matrix[s1, sh][metric]
        for s2 in list_of_pickups:
            #ALLOCATE_DEMAND[s1, s2] = 0
            transit_cost[s1, s2] = modelParameters.distance_matrix[s1, s2][metric]
    for sh in list_of_shelters:
        for sh2 in list_of_shelters:
            transit_cost[sh, sh2] = modelParameters.distance_matrix[sh, sh2][metric]
    
    if MODE_UNKNOWN_DEMAND == False:
        #itercount = 0
        iterkey = 0
        # DECIDE WHICH SHELTERS TO OPEN (INITIAL FEASIBLE SOLUTION)
        # 1. choose shelter with least remaining capacity first
        # 2. start adding pickup demand to chosen shelter until full
        # 3. choose next shelter with least remaining capacity
        # 4. repeat step 2-3 until all pickup demand is assigned somewhere
        demand_satisfied = False
        while not demand_satisfied:
            shkeys = list(remaining_capacity.keys())
            #chosen_shelter = min(remaining_capacity, key=remaining_capacity.get)
            chosen_shelter = shkeys[iterkey]
            
            k=0
            while remaining_capacity[chosen_shelter] >= PPA and k <= len(list_of_pickups)-1:
                s = list_of_pickups[k]
                agent_demand = pickup_demand_remaining[s]
                agent_caregiver_demand = pickup_demand_remaining[s] * PPA
                if agent_demand > 0:
                    if agent_caregiver_demand > remaining_capacity[chosen_shelter]:
                        iter_amount = 0
                        
                        while iter_amount * PPA < remaining_capacity[chosen_shelter]:
                            iter_amount += 1
                        
                        if remaining_capacity[chosen_shelter] % PPA == 0:
                            alloc_amount = iter_amount
                        else:
                            alloc_amount = iter_amount-1
                        
                    else:
                        alloc_amount = agent_demand
                    
                    if alloc_amount == pickup_demand_remaining[s]:
                        remaining_capacity[chosen_shelter] -= alloc_amount * PPA
                        pickup_demand_remaining[s] -= alloc_amount
                        ALLOCATE_DEMAND[s, chosen_shelter] += alloc_amount
                    
                k += 1
            
            
            ##if remaining_capacity[chosen_shelter] < PPA:
            ##    remaining_capacity.pop(chosen_shelter)
            
            #print(remaining_capacity)
            #for k in pickup_demand_remaining.keys():
            #    if pickup_demand_remaining[k] < 0:
            #        print(pickup_demand_remaining.values())
            #        break
            
            if sum(pickup_demand_remaining.values()) == 0:
                demand_satisfied = True
        
            if iterkey == len(shkeys)-1:
                iterkey = 0
            else:
                iterkey += 1
        
        current_shelter_availability = {k: adjusted_capacity[k] for k in adjusted_capacity.keys()}
        total_work_cost = 0
        for (s,sh) in ALLOCATE_DEMAND.keys():
            total_work_cost += ALLOCATE_DEMAND[s, sh] * transit_cost[s, sh]
            current_shelter_availability[sh] -= ALLOCATE_DEMAND[s, sh] * PPA
        print(total_work_cost)

    else:
        #itercount = 0
        iterkey = 0
        currentTier = [1]
        # DECIDE WHICH SHELTERS TO OPEN (INITIAL FEASIBLE SOLUTION)
        # 1. choose shelter with least remaining capacity first
        # 2. start adding pickup demand to chosen shelter until full
        # 3. choose next shelter with least remaining capacity
        # 4. repeat step 2-3 until all pickup demand is assigned somewhere
        
        for p in list_of_pickups:
            distance_to_shelters = {}
            for sh in list_of_shelters:
                if modelData.Shelters[sh].Tier in currentTier and remaining_capacity[sh] >= PPA:
                    distance_to_shelters[sh] = transit_cost[p,sh]
            chosen_shelter = min(distance_to_shelters, key=distance_to_shelters.get)
            #alloc_amount = pickup_demand_remaining[s]
            
            #remaining_capacity[chosen_shelter] -= alloc_amount * PPA
            ALLOCATE_DEMAND[p, chosen_shelter] += pickup_demand_remaining[p]
            pickup_demand_remaining[p] = 0 
            
        current_shelter_availability = {k: adjusted_capacity[k] for k in adjusted_capacity.keys()}
        
    return ALLOCATE_DEMAND, transit_cost, current_shelter_availability



def BuildRouteDictionary(list_of_shelters, list_of_pickups, transit_cost):
    
    # generate routes that cover all demands
    dict_of_routes = {}
    dict_of_transfers = {}
    x = 1
    y = 1
    for sh in list_of_shelters:
        for s in list_of_pickups:
            rID = 'R' + str(x)
            rNodes = [sh, s]
            rLengths = [transit_cost[s, sh], transit_cost[s, sh]]
            r = [rID, rNodes, rLengths]
            dict_of_routes[rID] = Route(r)
            x += 1
        for sh2 in list_of_shelters:
            if sh != sh2:
                tID = 'TR' + str(y)
                tNodes = [sh, sh2]
                tLength = [transit_cost[sh, sh2]]
                t = [tID, tNodes, tLength]
                dict_of_transfers[tID] = Transfer(t)
                y += 1
        
    for sh in list_of_shelters:
        for s1 in list_of_pickups:
            for s2 in list_of_pickups:
                if s1 != s2:
                    rID = 'R' + str(x)
                    rNodes = [sh, s1, s2]
                    rLengths = [transit_cost[s1, sh], transit_cost[s1, s2], transit_cost[s2, sh]]
                    r = [rID, rNodes, rLengths]
                    dict_of_routes[rID] = Route(r)
                    x += 1
                    
    return dict_of_routes, dict_of_transfers
                    
                    
def InitializeBusTrips(dict_of_routes, bus_route_assignment, list_of_buses, list_of_trips):

    count_duplicate_routes = {}
    for r in dict_of_routes.keys():
        for b in bus_route_assignment.keys():
            if r == bus_route_assignment[b][2]:
                if r in count_duplicate_routes.keys():
                    count_duplicate_routes[r] += 1
                else:
                    count_duplicate_routes[r] = 1
                  
    Y = 0
    bus_trips = {}
    for b in list_of_buses:
        x = 1
        rID = bus_route_assignment[b][2]
        nodes1 = dict_of_routes[rID].Nodes
        alternate_pair = [rID]
        if len(dict_of_routes[rID].Nodes) >= 3:
            shelter10 = nodes1[0]
            stop11 = nodes1[1]
            stop12 = nodes1[2]
            for r in dict_of_routes.keys():
                nodes2 = dict_of_routes[r].Nodes
                if len(nodes2) >= 3:
                    shelter20 = nodes2[0]
                    stop21 = nodes2[1]
                    stop22 = nodes2[2]
                    if stop11 == stop22 and stop12 == stop21 and shelter10 == shelter20:
                        alternate_pair = [rID, r]
        if b == 'B1':
            print(alternate_pair)
        
        y = 0
        for t in list_of_trips:
            rOrder = x
            
            if len(alternate_pair) > 1:
                if y == 0:
                    y = 1
                else:
                    y = 0
            
                if Y % 2 == 0:
                    tr = [t, alternate_pair[y], rOrder]
                else:
                    tr = [t, alternate_pair[1-y], rOrder]
                
            else:
                tr = [t, alternate_pair[0], rOrder]

            bus_trips[b, t] = Trip(tr)
            x += 1
        
        if len(alternate_pair) > 1:
            Y += 1
        
    
    return bus_trips




