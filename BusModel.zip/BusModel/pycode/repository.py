# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 14:40:06 2022

@author: Developer
"""





'''
newShelterCapacity = {}
for k in modelData.Shelters.keys():
    xList = modelOutputs.ShelteredAgentsEach[1, k]
    xCount = xList[-1]
    adjustShelterCapacity[k] = xCount
    #modelData.Shelters[k].Capacity = modelData.Shelters[k].Capacity - xCount
    newShelterCapacity[k] = newShelterCapacity[k] - xCount
    if newShelterCapacity[k] < 0:
        newShelterCapacity[k] = 0
        
for k in modelData.Shelters.keys():
    modelData.Shelters[k].Capacity = newShelterCapacity[k]
'''
###############################################################################
###############################################################################





#
# Set the shape paremeters
#

#
# Generate the value between
#
#
# Plot the beta distribution
#
'''
A, b = [1.2,2,5], 3

for a in A:
    m = (a/(a+b))
    print(m)
plt.figure(figsize=(7,7))
plt.xlim(0, 1)
for a in A:
    x = np.linspace(beta.ppf(0, a, b),beta.ppf(1, a, b), 100)
    plt.plot(x, beta.pdf(x, a, b), 'r-')
    plt.title('Beta Distribution', fontsize='15')
    plt.xlabel('Values of Random Variable X (0, 1)', fontsize='15')
    plt.ylabel('Probability', fontsize='15')
plt.show()


x = [x*60 for x in np.random.rayleigh(size=(2000), scale=1)]
#here we are using Rayleigh function to generate distributions of size 2000 with standard deviation 1
sb.distplot(x, hist=True, label='Rayleigh Distribution')
#plotting the graph
plt.show()





x = np.random.poisson(0.5*60, size=1000)
plt.figure(figsize=(7,7))
plt.xlim(0,8*60)
plt.hist(x)


'''


'''

dictOutput = EVACUATION_MODEL.pickup_wait_times
dictOutput = {k : np.array([x for x in dictOutput[k].values()]) for k in dictOutput.keys()}
dictSummary = {}
for k in dictOutput.keys():
    
    frame = pd.mean(dictOutput[k])
    
    


frame = pd.DataFrame.from_dict(dictOutput)



frame.columns = ['Wait Time (minutes)']
summary = frame.describe()
dictSummary[k] = frame
    
    


frame = pd.DataFrame.from_dict(dictSummary)
frame.columns = [k for k in dictSummary.keys()]

frame.describe()




results = EVACUATION_MODEL.dc.get_model_vars_dataframe()
#results['P111'].plot()

mylist = [key for key, val in dictOutput.items() for _ in range(val)]
plt.hist(mylist, bins=10)
plt.xticks = [i for i in range(0,2)]
plt.show()


fig, ax = plt.subplots()

ax.boxplot(dictOutput.values())
ax.set_xticklabels(dictOutput.keys())


my_dict = {'ABC': [34.54, 34.345, 34.761], 'DEF': [34.541, 34.748, 34.482]}

fig, ax = plt.subplots()
ax.boxplot(dictOutput.values())
ax.set_xticklabels(dictOutput.keys())

for k in dictOutput.keys():
    print(len(dictOutput[k]))




ax.show()



dictTable = {}
for k in dictOutput.keys():
    dictTable


frame = pd.DataFrame.from_dict(dictOutput, orient='index')
frame.columns = ['Wait Time']

frame.describe()

# Note that you can let the hist function do the groupby
# the function hist returns the list of axes created
axarr = frame.hist(column='Wait Time', by = 'index', sharex=True, sharey=True, layout = (2, 1))

for ax in axarr.flatten():
    ax.set_xlabel("Age")
    ax.set_ylabel("Individuals")




dictOutput = results['_evacuees_sheltered']
OUTPUT1_rows = []
temp_row = []
for v in dictOutput[0].keys():
    temp_row.append(v)
OUTPUT1_rows.append(temp_row)
for k in dictOutput.keys():
    temp_row = []
    for v in dictOutput[k].keys():
        temp_row.append(dictOutput[k][v])
    OUTPUT1_rows.append(temp_row)
    


OUTPUT1_rows = []
for k in dictOutput.keys():
    temp_row = []
    temp_row.append(k)
    temp_row.append(dictOutput[k])
    OUTPUT1_rows.append(temp_row)
    
    
with open(dir_output + '/output_queues.csv', 'w', newline='') as myfile:
     wr = csv.writer(myfile, quoting=csv.QUOTE_ALL)
     wr.writerows(OUTPUT1_rows)
     



model_df = EVACUATION_MODEL.dc.get_model_vars_dataframe()
agent_df = EVACUATION_MODEL.dc.get_agent_vars_dataframe()


from mesa.visualization.modules import CanvasGrid, ChartModule
from mesa.visualization.ModularVisualization import ModularServer

canvas = CanvasGrid(protrayal, 50, 50)
chart_count = ChartModule([bean, corn, soy, bug])

server = ModularServer(Foraging, [canvas, chart_count], name="Foraging", strategy="stick")

server.launch()




from multiprocessing import freeze_support
from mesa.batchrunner import FixedBatchRunner
from tqdm import tqdm_notebook


%matplotlib inline

def run(time, **kwargs):

    #result = {"ST1": []}
    model = Evacuation(NEIGHBORHOODS, STOPS, ASSIGNMENTS,
                                  dictWalkTimes,
                                  BUS, BUSROUTES, bus_distance_matrix,
                                  demand, LOAD_TIME, CAPACITY)

    progress = tqdm_notebook(total=time)
    for t in range(time):
        model.step()
        
        
        #result["ST1"].append(model.number_of_bean)

        progress.update()

    progress.close()

    return pd.DataFrame(result)


result = run(24*60)

show(result, strategy)














             
variable_params = { "load_time" : 10, "capacity" : 10}

fixed_params = {"NEIGHBORHOODS" : NEIGHBORHOODS, 
          "STOPS" : NEW_STOPS, 
          "WALK_DISTANCES" : dictWalkTimes, 
          "BUS" : BUS, 
          "BUSROUTES" : BUSROUTES, 
          "bus_distance_matrix" : bus_distance_matrix, 
          "DEMAND" : demand,
          "load_time" : 10, 
          "capacity" : 10}
         


if __name__ == '__main__':
    freeze_support()
    results = FixedBatchRunner(
            Evacuation,
            parameters_list=None,
            fixed_parameters=fixed_params,
            iterations=1,
            max_steps=300,
            model_reporters=None,
            agent_reporters=None,
            display_progress=True
    )

results_df = DataFrame(results)
'''



#gs = GridSpec(2, 2, width_ratios=[30, 1])
#f = plt.figure(figsize=(8, 8))
#top_ax = f.add_subplot(gs[0, :])


#model_df.plot()



    

# generate sample bus route...
#orig_node = ox.get_nearest_node(G, (lat, lon))
#dest_node = ox.get_nearest_node(G, (dropoff_lat, dropoff_lon)) #ERROR
#route_bus = nx.shortest_path(G, orig_node, dest_node, weight='length')
#route_list.append(route_bus)

#ec = ox.plot.get_edge_colors_by_attr(G, attr='length')
#fig, ax = ox.plot_graph_routes(G, route_list, node_size=0, edge_color=ec, bgcolor='k')


#route_colors = ['r','r','r','r','r','b']
    
    
    
    
    
    

# Read hazard mapping data
#extents = gpd.read_file(os.path.join(dir_input, '47260_au_2018_0800.gpkg'))
#domain = gpd.read_file(os.path.join(dir_input, '47260_au_2018_0800.gpkg')).geometry[0]
#G = ox.graph_from_polygon(domain, network_type = 'drive')
#hazplot = extents.plot(ax=ax, alpha=1, color='#999999')
#hazplot.show()

'''
import matplotlib
import networkx as nx

mapping_data = os.path.join(os.path.realpath('../'), 'data')
outputs = os.path.join(os.path.realpath('../'), 'outputs')


if not os.path.exists(outputs):
    os.mkdir(outputs)
    
def read_model(path):
    agent_df = pd.read_csv(path + '.agent.csv', index_col='Step', dtype={'highway': pd.Int64Dtype()})
    
    model_df = pd.read_csv(path + '.model.csv')
    
    graph = nx.read_gml(path + '.gml')
    nodes, edges = ox.save_load.graph_to_gdfs(graph)
    nodes.index = pd.read_csv(path + '.model.csv')
    
    geopackage = path + '.gpkg'
    
    hazard = gpd.read_file(geopackage, layer='hazard')
    target_nodes = gpd.read_file(geopackage, layer='targets')
    target_nodes = nodes.index.astype('int64')
    
    return agent_df, model_df, graph, nodes, edges, hazard, target_nodes

    
    
    
extents = gpd.read_file(os.path.join(mapping_data, '47260_au_2018_0800.gpkg'))

agent_df, model_df, graph, nodes, edges, hazard, target_nodes = read_model(outputs)

#f, ax = ox.plot_graph(graph, show=True, dpi=200, node_size=0, 
#                         edge_color='#999999', edge_linewidth=0.5)
#extents.plot(ax=ax, alpha=1, color='#999999')


class VirginiaBeachEvacuationModel(TestModel):
    
    def model_download(self):
        domain = gpd.read_file(os.path.join(mapping_data, 
                                            '47260_au_2018_0800.gpkg')).geometry[0]
        EvacuationModel(domain=domain, output_path=os.path.join(outputs, 'download'),seed=1, hazard=extents)

    def model_run(self):
        import networkx as nx
        model_path = os.path.join(mapping_data, 'virginiabeach_model')
        geopackage = model_path + '.gpkg'
        agents = gpd.read_file(geopackage, layer='agents')
        targets =gpd.read_file(geopackage, layer='targets')
        network = nx.read_gml(model_path + '.gml')
        
        EvacuationModel(agents=agents, 
                        targets=targets, 
                        network=network, 
                        output_path=os.path.join(outputs, 'virginiabeach_model'),
                        seed=1,
                        hazard=extents).run(50)
        
class EvacuationModel(Model):
    
    def __init__(
            self,
            hazard: GeoDatFrame,
            output_path: str,
            domain: Optional[Polygon] = None,
            target_types: Iterable[str] = tuple(['school']),
            network: Optional[Graph] = None,
            targets: Optional[GeoDataFrame] = None,
            target_capacity: int = 100,
            agents: Optional[GeoDataFrame] = None,
            seed: Optional[int] = None):
        super().__init__()
        self.seed = seed
        self.output_path = output_path
        self.hazard = hazard
        self.schedule = RandomActivation(self)
        self.target_capacity = target_capacity
        
        if network is None:
            self.G = osmnx.graph_from_polygon(domain, simplify=False)
            self.G = self.G.to_undirected()
        else:
            self.G = network
            
        self.nodes: GeoDataFrame
        self.edges: GeoDataFrame
        self.nodes, self.edges = osmnx.save_load.graph_to_gdfs(self.G)
        
        if agents is None:
            agents = GeoDataFrame(geometry = geometry_create_footprints_gdf(domain).centroid)
        
        if targets is None:
            targets = osmnx.pois_from_polygon(domain, amenities=list(target_types))
            targets = targets[targets.geometry.geom_type == 'Point']
        
        output_gpkg = output_path + '.gpkg'
        
        driver = 'GPKG'
        
        targets.crs, agents.crs = [self.nodes.crs] * 2
        
        nodes_tree = cKDTree(np.transpose([self.nodes.geometry.x, self.nodes.geometry.y]))
        
        self.hazard.crs = self.nodes.crs
    
        
model = VirginiaBeachEvacuationModel


#class VirginiaBeachEvacuationModel(VirginiaBeachCase):
#    
#    def virginiabeach_model_download(self):
#        domain = gpd.read_file(os.path(join(mapping_data, 'virginia_beach.gpkg')))







from mesa import Agent, Model
from mesa.time import RandomActivation
from mesa.datacollection import DataCollector
from mesa.space import MultiGrid


RANDOM_SEED = 1
SIM_TIME = 999
NUM_BUSES = 2
CAPACITY = 8
LOAD_TIME = 5

NEIGHBORHOODS = dict({'Bay Point':[36.88724327068927, -76.03529146759959, 10],
                      'Ashley':[36.8852524990746, -76.02293133172432, 10],
                      'Duke of Windsor':[36.87766639965166, -76.02301760717629, 10],
                      'Whittier':[36.87910819696094, -76.0266651296041, 10],
                      'Mill Dam':[36.878833451272484, -76.03318788383821, 10]})

STOPS = dict({'BUS STOP': [36.883330237406255, -76.03211531884615]})


class Evacuee(Agent):
    def __init__(self, name, model):
        super().__init__(name, model)
        self.name = name
        
        # Time required to respond to evacuation order
        self._home = True
        self._packed = False
        self._waiting_for_bus = False
    
    def pack_up(self):
        self.group_size = 1 # people
        self.time_to_pack = 60 # minutes
        self._packed = True
        
    def go_to_busstop(self):
        self._home = False
    
    def arrive_at_busstop(self):
        self._waiting_for_bus = True
        
        
    def step(self):
        if self._home == True:
            self.pack_up()
        elif self._pack_up == True:
            self.go_to_busstop()
        elif self._waiting_for_bus == True:
            return
        
        

class Evacuation(Model):
    
    def __init__(self, NEIGHBORHOODS, STOPS):
        super().__init__()
        self.schedule = RandomActivation(self)

        for n in NEIGHBORHOODS:
            #busstop = STOPS[n]
            population = NEIGHBORHOODS[n][2]
            nlat = NEIGHBORHOODS[n][0]
            nlon = NEIGHBORHOODS[n][1]
            slat = STOPS['BUS STOP'][0]
            slon = STOPS['BUS STOP'][1]
            for i in range(1, population+1):
                unique_id = '%s_P%s' % (n, i)
                e = Evacuee(unique_id, self)
                self.schedule.add(e)
                
        self.dc = DataCollector(model_reporters={"arrived_at_busstops=":
                                    lambda m: m.schedule.get_agent_count()},
                                agent_reporters={"name": lambda e: e.name})
    
    def step(self):
        self.schedule.step()
        self.dc.collect(self)
    
    
model = Evacuation(NEIGHBORHOODS, STOPS)

for t in range(10):
    model.step()

model_df = model.dc.get_model_vars_dataframe()
agent_df = model.dc.get_agent_vars_dataframe()
    
    
    
    

def GetDistance(G, NEIGHBORHOODS, STOPS, equal_args):
    distance_matrix = {}
    for n in NEIGHBORHOODS.keys():
        pickup_coords = NEIGHBORHOODS[n]
        pickup_lat = pickup_coords.Latitude
        pickup_lon = pickup_coords.Longitude
        
        orig_node = distance.nearest_nodes(G, pickup_lon, pickup_lat)
        
        for s in STOPS.keys():
            dropoff_lat = STOPS[s].Latitude
            dropoff_lon = STOPS[s].Longitude
            dest_node = distance.nearest_nodes(G, dropoff_lon, dropoff_lat)
            route = shortest_path(G, orig_node, dest_node, weight='length')
            d = int(sum(utils_graph.get_route_edge_attributes(G, route, "length")))
            t = int(sum(utils_graph.get_route_edge_attributes(G, route, "travel_time")))
            d = round(d/1000, 2)
            t = round(t/60, 2)
            if t == 0:
                speed = 0
            else:
                speed = round(d/(t/60), 2)
            #print('neighborhood=' + str(n) + ', stop=' + str(s) + ', d=' + str(d))
            distance_matrix[n, s] = (d, t, speed)
        
        if equal_args == False:
            for n2 in NEIGHBORHOODS.keys():
                dropoff_coords = NEIGHBORHOODS[n2]
                dropoff_lat = dropoff_coords.Latitude
                dropoff_lon = dropoff_coords.Longitude
                dest_node = distance.nearest_nodes(G, dropoff_lon, dropoff_lat)
                route = shortest_path(G, orig_node, dest_node, weight='length')
                d = int(sum(utils_graph.get_route_edge_attributes(G, route, "length")))
                t = int(sum(utils_graph.get_route_edge_attributes(G, route, "travel_time")))
                d = round(d/1000, 2)
                t = round(t/60, 2)
                if t == 0:
                    speed = 0
                else:
                    speed = round(d/(t/60), 2)
                #print('neighborhood=' + str(n) + ', stop=' + str(n2) + ', d=' + str(d))
                distance_matrix[n, n2] = (d, t, speed)
            
    return distance_matrix
    
    '''
    
    