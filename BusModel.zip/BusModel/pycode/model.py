# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 14:38:14 2022

@author: Developer
"""

from mesa import Model
from mesa.time import RandomActivation
from mesa.datacollection import DataCollector
import random
import numpy as np
from scipy.stats import poisson


from agents import Bus, Evacuee

class Evacuation(Model):
    
    def __init__(self, modelData, modelConfig, modelParameters):
        
        
        super().__init__()
        self.schedule = RandomActivation(self)
        self.activity_log = []
        #interval = random.uniform(5,5+10) # minutes
        
        number_of_agents_waiting = {}
        #buses_available_at_stop = {}
        queue_agents_waiting_for_pickup = {}
        agent_pickup_wait_times = {}
        for s in modelData.Stops.keys():
            number_of_agents_waiting[s] = 0
            #buses_available_at_stop[s] = []
            queue_agents_waiting_for_pickup[s] = []
            agent_pickup_wait_times[s] = {}
            
        number_of_agents_at_shelter = 0
        
        list_agents_in_bus = {}
        for k in modelParameters.BUS.keys():
            list_agents_in_bus[k] = []
            
        list_shelter_agents = {}
        shelter_capacity = {}
        roster_all_shelter_agents = []
        for sh in modelParameters.ADJUSTED_CAPACITY.keys():
            list_shelter_agents[sh] = []
            shelter_capacity[sh] = modelParameters.ADJUSTED_CAPACITY[sh]
            
        self.WHEELCHAIR_LOADTIME = modelConfig.TIME_PER_WHEELCHAIR_LOAD
            
        self.SHELTERS = modelData.Shelters
        self.SHELTER_CAPACITY = shelter_capacity
        self.list_shelter_agents = list_shelter_agents
        self.roster_all_shelter_agents = roster_all_shelter_agents
        self.bus_distance_matrix = modelParameters.distance_matrix
        
        self.agent_arrival_time = {k: {} for k in modelData.Stops.keys()}
        self.number_of_agents_at_shelter = number_of_agents_at_shelter
        self.number_of_agents_waiting = number_of_agents_waiting
        #self.buses_available_at_stop = buses_available_at_stop
        self.queue_agents_waiting_for_pickup = queue_agents_waiting_for_pickup
        self.agent_pickup_wait_times = agent_pickup_wait_times
        self.list_agents_in_bus = list_agents_in_bus
        
        self.RecordPackingTimes = []
        self.RecordShelterArrivals = []
        self.RecordTransitTimes = {}
        
        self.PEOPLE_PER_AGENT = modelConfig.PEOPLE_PER_AGENT
        
        self.time_counter = 0
        self.outputPickupQueues = {}
        
        self.BUS = {k: modelParameters.BUS[k] for k in modelParameters.BUS.keys()}
        
        self.LastVisit = {s: 0 for s in modelData.Stops.keys()}
        self.MinDelay = modelConfig.BUS_MIN_INTERVAL
        self.MaxDelay = modelConfig.BUS_MAX_INTERVAL
        self.BusDwellTime = {b: [] for b in modelParameters.BUS.keys()}
        
        self.BUSROUTES = {k: modelParameters.BUSROUTES[k] for k in modelParameters.BUSROUTES.keys()}
        self.TRANSFERROUTES = {k: modelParameters.TRANSFERROUTES[k] for k in modelParameters.TRANSFERROUTES.keys()}
        self.BUSTRIPS = {k: modelParameters.BUSTRIPS[k] for k in modelParameters.BUSTRIPS.keys()}
        self.activity_log_labels = []
        
        self.ShelterTierAvailable = [1]
        
        for k in self.BUS.keys():
            bus_trips = {}
            route_id = self.BUS[k][2]
            #load_time = 1 # per evacuee
            #capacity = 10 # evacuees
            
                
            j = 1
            for (b,t) in self.BUSTRIPS.keys():
                if b == k:
                    bus_trips[j] = self.BUSTRIPS[b,t]
                    j += 1
            
            '''
            for r in modelParameters.BUSROUTES.keys():
                if modelParameters.BUSROUTES[r].Route == route_id:
                    
                    route_orig = modelParameters.BUSROUTES[r][1]
                    route_dest = modelParameters.BUSROUTES[r][2]
                    route_order = modelParameters.BUSROUTES[r][4]
                    action = modelParameters.BUSROUTES[r][5]
                    
                    
                    travel_time = modelParameters.distance_matrix[route_orig, route_dest][1]
                    travel_time = generateRandomVariable(travel_time, 'Poisson')    
                    
                    
                    bus_trips[route_order] = [route_orig, route_dest, travel_time, action]
            '''
            #interval = 0
            b = Bus(k, self, bus_trips, modelConfig)
            self.schedule.add(b)
            #interval += interval
        
            
        
        x = 1
        for s in modelData.Stops:
            for n in modelParameters.ASSIGNMENTS[s]:
                
                #gathertime += 20
                #busstop = STOPS[n]
                population = modelData.Population[n].NumPeople
                walk_time = modelParameters.dictWalkTimes[n][0]
                orig = n
                destination = modelParameters.dictWalkTimes[n][1]
                for i in range(1, population+1):
                    
                    rndDice = random.uniform(0,1)
                    if rndDice <= modelConfig.PERCENT_IN_WHEELCHAIR:
                        unique_id = '%s_Person%d_wheelchair' % (n, x)
                    else:
                        unique_id = '%s_Person%d' % (n, x)
                        
                    x += 1
                    
                    v0 = 0
                    v1 = modelConfig.ARRIVAL_WINDOW
                    v2 = modelConfig.ARRIVAL_WINDOW
                    
                    
                    ### SPECIFY ARRIVAL DISTRIBUTIONS HERE ###
                    rndDice = random.uniform(0,1)
                    if rndDice <= 1:
                        leave_time = [v0, v1]
                        rndPackTime = generateRandomVariable(v1, 'Rayleigh')
                    else:
                        leave_time = [v0, v1, v2]
                        rndPackTime = generateRandomVariable(leave_time, 'Rayleigh') 
                        
                    # "Walk time" = time to get from homes to bus stop
                    # This is not really a walk because it assumes same
                    # travel speed as buses.
                    rndWalkTime = generateRandomVariable(walk_time, 'Poisson') 
                    
                    self.RecordPackingTimes.append(rndPackTime)
                    
                    #print(rndPackTime)
                    
                    e = Evacuee(unique_id, self, rndPackTime, rndWalkTime, orig, destination)
                    self.schedule.add(e)
                    
        data = {}
        for s in modelData.Stops:
            data[s] = lambda m: m.number_of_agents_waiting[s]
        
        #data['_evacuees_sheltered'] = lambda m: m.number_of_agents_at_shelter
        
        self.dc = DataCollector(model_reporters=data,
                                agent_reporters={"name": lambda e: e.name})
        
    def step(self):
        self.schedule.step()
        self.dc.collect(self)
        
        #print(self.dc.model_reporters['P111'])
        
        #print(self.number_of_agents_waiting)
        
        self.time_counter += 1
        #print(self.number_of_agents_waiting['P111'])
        
        
        
def generateRandomVariable(exp, distribution_type):
    
    if distribution_type == 'Poisson':
        obs=exp
        rng1 = np.arange(0, 2*exp, 0.1)
        rng2 = poisson.cdf(rng1, mu=exp)
        rndDice = random.uniform(0,1)
        for i in range(0,len(rng2)-1):
            if rndDice >= rng2[i] and rndDice < rng2[i+1]:
                obs = rng1[i]
                break
        
    elif distribution_type == 'Triangular':
        obs = np.random.triangular(exp[0], exp[1], exp[2], size=1)
        
    elif distribution_type == 'Uniform':
        obs = np.random.uniform(exp[0], exp[1], size=1)
        
    elif distribution_type == 'Rayleigh':
        obs = np.random.rayleigh(size=1, scale=exp)[0]
        
    return obs
    