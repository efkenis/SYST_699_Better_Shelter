# -*- coding: utf-8 -*-
"""
Created on Thu Mar 24 10:10:54 2022

@author: Tim Rogers

Description: This is a bus routing and simulation model for an evacuation in
             Virginia Beach. A combination of basic routing heuristics and
             agent-based simulation is used to produce outputs for a zone- and
             tier-based evacuation to local shelters. The input file must
             include a list of population nodes and shelters with capacity.
             The simulation moves buses along routes to and from pickups to
             shelters until everyone is successfully evacuated.

Instructions:
    1. Open START.py to set parameters
    2. Run main.py
    3. Optional: Some parameters like arrival distribution must be changed
       within the model.py, batch.py, and agent.py files
    
*Initial shelter occupancy can be modified within main.py (main batch loop)
*Running selections of code manually can save time, as some tasks do not need
 to be repeated, such as the mapping and node dictionary initialization.
 
Notes for future development are included throughout the code. The primary
areas for improvement include the need for shorter loading times for mapping
and route networks, the need for more refined routing heuristics, and the need
for more refined code structure/organization throughout the whole tool. Some
additional areas for improvement include bus dynamics, home-to-pickup modeling
(some is already included in code, but not implemented), and use of Gurobi or
CPLEX to generate optimized route solutions.
"""



from mapping import InitializeMap, filterByZone, scalePopulation, displayMap
from routing import GenerateRouting, BuildRoutes #ModifyBusNetwork
from routing import CalculateDemand
#from model import Evacuation
from START import Configure_Inputs
from data import GetModelData
#from csv import writer, QUOTE_ALL
#from os import path, remove
from class_objects import modelParameters, modelOutputs
from batch import RunExperiments, ShowSummaryStatistics, SaveActivityLog
from batch import SaveSummaryReport, CreateBoxPlot, PlotArrivalDistributions
from batch import PlotShelterAllOccupancy, PlotShelterEachOccupancy
from batch import PlotWaitTimes, PlotDistanceDemand, PlotBusStopWaitTimeVsTime
from batch import PlotLines
import matplotlib.pyplot as plt

from heuristics import FacilityAllocation, InitializeFacilityCapacity, FacilityInitialSolution
from heuristics import BuildRouteDictionary, InitializeBusTrips

import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import beta

boxplotWAIT = {}
boxplotSUMMARY = {}
infoSUMMARY = {}

###############################################################################
###                       INITIALIZE MAP AND ROUTES                         ###
###############################################################################
### GET INPUT PARAMETERS FROM START.py ###
modelConfig = Configure_Inputs()
modelOutputs = modelOutputs
modelData = GetModelData(modelConfig) #EXCEL IMPORT

### Initialize OSMNx mapping object ###
# NOTE FOR FUTURE DEVELOPERS: Can this file be saved to speed things up?
G = InitializeMap()
    
### Perform filtering and scaling operations on population ###
modelData.Population = filterByZone(modelConfig, modelData)
modelData.Population = scalePopulation(modelConfig, modelData)


# THIS OPTIONAL CODE ALLOWS DISPLAY OF PICKUP POINTS AND POPULATION NODES ONLY
# NO ROUTES; TAKES LESS TIME TO GENERATE HTML MAP
#route_list = {}
#displayMap(G, modelConfig, modelData, modelParameters, route_list, 'lite')


# Create initial matrix of distances between all neighborhoods and stops
# Distance | Time | Speed (km, minutes, km/h)
# NOTE FOR FUTURE DEVELOPERS: THIS IS A BOTTLENECK! Needs to be sped up.
print('Generating routing (this may take a few minutes)')
busroute_add = [] # ignore this input
GenerateRouting(G, modelData, modelConfig, modelParameters, busroute_add)
    
# Which zones to evacuate (from configuration)
myzone = modelConfig.ZONES_TO_EVACUATE[0]

MinNumberBuses = modelConfig.MIN_NUMBER_BUSES
MaxNumberBuses = modelConfig.MAX_NUMBER_BUSES
# Nothing here should be altered.
outputData1 = {'header': ['MaxClearanceTime']}
outputData2 = {'header': ['PercentAbove60','PercentAbove45','PercentAbove30']}
outputData3 = {}
outputData4 = {} 
outputData5 = {}
outputData6 = {}
outputData7 = {}
maxwait_stop = ''
calibration = 1
cDelta = 0.01
required_number = list(range(MinNumberBuses,MaxNumberBuses+1))
starting_number = required_number[0]
COUNT_BUSES = 0





# IMPORTANT INPUT: Choose solution method
mymethod = modelConfig.SOLVE_METHOD
if mymethod == 'AddBusToRouteWithMaxWait':
    MODE_CALIBRATION = True
    MODE_ADD_BUSES = True
    MODE_UNKNOWN_DEMAND = True
elif mymethod == 'UseCapacitatedFacilityAllocation':
    MODE_CALIBRATION = True
    MODE_ADD_BUSES = True
    MODE_UNKNOWN_DEMAND = False
else:
    MODE_CALIBRATION = True
    MODE_ADD_BUSES = False
    MODE_UNKNOWN_DEMAND = False
    
    
########################### MAIN BATCH RUNNER LOOP ############################
# Description: This loop runs the route-generation and simulation procedures
#              under different parameters. Each iteration of this loop includes
#              a specified number of buses, routes, pickups, and a set number
#              of simulation runs to create statistically significant outputs.
# Steps: 1. Allocate demand from pickups to shelters. Each pickup goes entirely
#           to one shelter unless during the simulation the shelter fills and
#           bus must re-route. Buses travel to same pickups without exception.
#           The routing solution must adhere to allocation plan if possible.
#        2. Generate routes and bus assignments.
#        3. Run simulations
#        4. Post-process output data
#        5. Generate output graphics

while len(required_number) > 0:
    
    demand = CalculateDemand(modelData, modelParameters, modelConfig)
    #avg_distance_demand_per_bus = sum(distance_demand.values()) / num_buses
    
    
    # make list of pickup spots
    list_of_pickups = []
    for s in modelParameters.ASSIGNMENTS.values():
        if len(s) > 0:
            list_of_pickups.append(s[0])
    
    pickup_demand = {}
    pickup_demand_remaining = {}
    for s in list_of_pickups:
        pickup_demand[s] = demand[s]
        pickup_demand_remaining[s] = demand[s]
    
    initial_occupancy = {sh: 0 for sh in modelData.Shelters.keys()}
    initial_occupancy['SH11'] = 0 #224+150 # set initial shelter occupancy
    initial_occupancy['SH12'] = 0 #180+878
    initial_occupancy['SH13'] = 0 #224+306
    #initial_occupancy['SH21'] = 226
    #initial_occupancy['SH22'] = 394
    #initial_occupancy['SH23'] = 338
    
    
    list_of_shelters, adjusted_capacity, remaining_capacity = InitializeFacilityCapacity(modelConfig, 
                                                                                         modelData, 
                                                                                         pickup_demand, 
                                                                                         initial_occupancy,
                                                                                         MODE_UNKNOWN_DEMAND)
    
    
    ALLOCATE_DEMAND, transit_cost, current_shelter_availability = FacilityInitialSolution(modelData, modelParameters, list_of_pickups, list_of_shelters, pickup_demand_remaining, 
                                                                                          adjusted_capacity, remaining_capacity, MODE_UNKNOWN_DEMAND)
    
    
    if MODE_UNKNOWN_DEMAND == False:
        ALLOCATE_DEMAND, current_shelter_availability = FacilityAllocation(ALLOCATE_DEMAND, transit_cost, 
                                                                           current_shelter_availability,
                                                                           adjusted_capacity)
    
    '''
    templist = []
    for r in bus_route_assignment.keys():
        if bus_route_assignment[r][2] not in templist:
            templist.append(bus_route_assignment[r][2])
    
    templist = {}
    for r in bus_route_assignment.keys():
        sh = bus_route_assignment[r][0]
        if sh not in templist.keys():
            templist[sh] = 1
        else:
            templist[sh] += 1
    '''
    
    active_links = [k for k in ALLOCATE_DEMAND.keys() if ALLOCATE_DEMAND[k] > 0]
    
    #for (p,sh) in ALLOCATE_DEMAND.keys():
    #    if sh == 'SH12' and ALLOCATE_DEMAND[p,sh]  > 0 :
    #        print('%s, %s, %d' % (p,sh,ALLOCATE_DEMAND[p,sh]))

    while COUNT_BUSES < required_number[0] and MODE_CALIBRATION == True:
        
        
        # ESTIMATE 
        number_buses = {}
        number_buses_shelter = {sh: 0 for sh in list_of_shelters}
        number_buses_pickup = {s: 0 for s in list_of_pickups}
        for k in active_links:
            s = k[0]
            sh = k[1]
            CLEARANCE_TIME_OBJECTIVE = 12*60 #arbitrary value
            buscap = modelConfig.ADJUSTED_BUS_CAPACITY
            fixed_time = buscap * modelConfig.TIME_PER_AGENT_LOAD_BUS
            #calibration = 50
            N = (2 * ALLOCATE_DEMAND[s, sh] * (calibration*fixed_time + transit_cost[s, sh]))/(CLEARANCE_TIME_OBJECTIVE * buscap)
            number_buses[s, sh] = N
            number_buses_shelter[sh] += N
            number_buses_pickup[s] += N
        
        # NUMBER OF BUSES PER SHELTER
        pickup_shelter = {}
        shelter_pickups = {}
        for sh in number_buses_shelter.keys():
            if MODE_UNKNOWN_DEMAND == False:
                if number_buses_shelter[sh] > 0:
                    number_buses_shelter[sh] = max(1,round(number_buses_shelter[sh]))
                else:
                    number_buses_shelter[sh] = 0
            else:
                if number_buses_shelter[sh] > 0:
                    number_buses_shelter[sh] = max(1,round(number_buses_shelter[sh]))
                else:
                    number_buses_shelter[sh] = 0
                
            shelter_pickups[sh] = [k[0] for k in active_links if k[1] == sh]
        for p in list_of_pickups:
            pickup_shelter[p] = [k[1] for k in active_links if k[0] == p]
        
        COUNT_BUSES = sum(number_buses_shelter.values())
        calibration += cDelta
        #print(COUNT_BUSES)
    
    initial_utilized_shelters = [sh for sh in number_buses_shelter.keys() if number_buses_shelter[sh] > 0]
    required_number = required_number[slice(1,None)]
    
    dict_of_routes, dict_of_transfers = BuildRouteDictionary(list_of_shelters, list_of_pickups, transit_cost)

    
    print(COUNT_BUSES)
    starting_num_buses = COUNT_BUSES
    list_of_buses = ['B' + str(x) for x in range(1, starting_num_buses+1)]
    list_of_trips = ['T' + str(x) for x in range(1,500+1)]
    bus_route_assignment = {}
    
    
    fractional_buses_assigned_to_pickup = {n: 0 for n in list_of_pickups}
    number_buses_assigned_to_pickup = {n: 0 for n in list_of_pickups}
    coverage_gap = {s: number_buses_pickup[s] for s in list_of_pickups for r in dict_of_routes.keys()}
    i = 0
    
    if COUNT_BUSES < len(list_of_pickups) / 2:
        print('Insufficient number of buses.')
        
    elif COUNT_BUSES >= len(list_of_pickups) / 2 and COUNT_BUSES < len(list_of_pickups):
        number_of_double_routes = len(list_of_pickups) - COUNT_BUSES
        
    
    
    iCountDoubles = 0
    # SEARCH FOR FEASIBLE ROUTES
    # MUST ADHERE TO FACILITY ALLOCATION RULES
    for sh in number_buses_shelter.keys():
        if len(shelter_pickups[sh]) > 0:
            shStops = shelter_pickups[sh]
            #print('Assessing shelter %s' % sh)
            for x in range(0,number_buses_shelter[sh]):
                bID = list_of_buses[i]
                bLength = {}
                temp_dict = {k: coverage_gap[k] for k in coverage_gap.keys() if k in shStops}
                
                biggest_gap2 = [k for k in number_buses_assigned_to_pickup.keys() if number_buses_assigned_to_pickup[k] == 0]
                
                biggest_gap1 = [max(temp_dict, key=temp_dict.get)]
                #print('Assessing pickup %s with largest gap (gap = %d)' % (biggest_gap, coverage_gap[biggest_gap]))
                choices = []
                
                # SEARCH ALL POSSIBLE ROUTES
                for r in dict_of_routes.keys():
                    rNodes = dict_of_routes[r].Nodes
                
                    # Route connects to feasible pickup
                    if sh in rNodes:
                        
                        rLength = sum(dict_of_routes[r].Lengths)
                        #print(dict_of_routes[r].Nodes)
                        
                        if len(biggest_gap2) > 0:
                            if rNodes[1] in biggest_gap2:
                                choices.append(dict_of_routes[r])
                                bLength[r] = rLength
                        if len(biggest_gap1) > 0:
                            if rNodes[1] in biggest_gap2:
                                choices.append(dict_of_routes[r])
                                bLength[r] = rLength
                        if len(rNodes) == 3:
                            if len(biggest_gap2) > 0:
                                if rNodes[2] in biggest_gap2:
                                    choices.append(dict_of_routes[r])
                                    bLength[r] = rLength
                            if len(biggest_gap1) > 0:
                                if rNodes[2] in biggest_gap1:
                                    choices.append(dict_of_routes[r])
                                    bLength[r] = rLength
                
                if len(bLength) > 0:
                    rChoice = min(bLength, key=bLength.get)
                else:
                    print('Warning: Could not satisfy allocation plan.')
                    
                if len(dict_of_routes[rChoice].Nodes) == 3:
                    iCountDoubles += 1
                for n in dict_of_routes[rChoice].Nodes:
                    if n != sh:
                        coverage_gap[n] -= 1/(len(dict_of_routes[rChoice].Nodes)-1)
                bus_route_assignment[bID] = (sh, [n for n in dict_of_routes[rChoice].Nodes if n != sh], rChoice)
                for n in dict_of_routes[rChoice].Nodes:
                    if n in list_of_pickups:
                        number_buses_assigned_to_pickup[n] += 1
                        fractional_buses_assigned_to_pickup[n] += 1/(len(dict_of_routes[rChoice].Nodes)-1)
                i += 1
    
    '''
    estimated_shelter_load = {sh: 0 for sh in list_of_shelters}
    for sh in list_of_shelters:
        for r in bus_route_assignment.keys():
            shN = bus_route_assignment[r][0]
            nodes = bus_route_assignment[r][1]
            if shN == sh:   
                for n in nodes:
                    fraction_allocated_to_node = 1/len(nodes)
                    num_buses_serving_node = fractional_buses_assigned_to_pickup[n]
                    fraction_allocated_to_node / num_buses_serving_node
                    estimated_shelter_load[sh] += pickup_demand[n] * modelConfig.PEOPLE_PER_AGENT * fraction_allocated_to_node / num_buses_serving_node
    '''
    
                
    # ENSURE NO PICKUP IS LEFT UNCOVERED
    uncovered_pickup = [1]
    while len(uncovered_pickup) > 0:
        
        uncovered_pickup = []
        for n in list_of_pickups:
            foundit = False
            for d in bus_route_assignment.keys():
                if n in bus_route_assignment[d][1]:
                    foundit = True
            if foundit == False:
                uncovered_pickup.append(n)
                        
            
        if len(uncovered_pickup) > 0:
            n = uncovered_pickup[0]
        
            mydemand = pickup_demand[n]
            shN = max(current_shelter_availability, key=current_shelter_availability.get)
            
            myshelters = pickup_shelter[n]
            
            # CHOOSE BUSES WHO ARE ONLY VISITING 1 PICKUP LOCATION
            feasible_set = {}
            for b in bus_route_assignment.keys():
                bus_shelter = bus_route_assignment[b][0]
                number_nodes = len(bus_route_assignment[b][1])
                
                # BUS MUST USE THE SAME SHELTER
                if number_nodes == 1 and bus_shelter in myshelters:
                    for r in dict_of_routes.keys():
                        rNodes = dict_of_routes[r].Nodes
                        existing_node = bus_route_assignment[b][1][0]
                        missing_node = n
                        if bus_shelter in rNodes and existing_node in rNodes and missing_node in rNodes:
                            rLength = sum(dict_of_routes[r].Lengths)
                            feasible_set[b, r] = rLength
                            
            if len(feasible_set) == 0: #break allocation rules
                for b in bus_route_assignment.keys():
                    bus_shelter = bus_route_assignment[b][0]
                    number_nodes = len(bus_route_assignment[b][1])
                    existing_node = bus_route_assignment[b][1][0]
                    
                    # BUS MUST USE THE SAME SHELTER
                    if number_nodes == 1:
                        for r in dict_of_routes.keys():
                            rNodes = dict_of_routes[r].Nodes
                            missing_node = n
                            if missing_node in rNodes and existing_node in rNodes and rNodes[0] in initial_utilized_shelters:
                                rLength = sum(dict_of_routes[r].Lengths)
                                feasible_set[b, r] = rLength
                                
                                
            if len(feasible_set) > 0:
                mychoice = min(feasible_set, key=feasible_set.get)
                
                existing_node = bus_route_assignment[mychoice[0]][1][0]
                SH0 = bus_route_assignment[mychoice[0]][0]
                bus_route_assignment[mychoice[0]] = (SH0, [n for n in dict_of_routes[mychoice[1]].Nodes if n not in list_of_shelters], mychoice[1])
                for n2 in dict_of_routes[mychoice[1]].Nodes:
                    if n2 not in list_of_shelters:
                        coverage_gap[n2] -= 1/(len(dict_of_routes[mychoice[1]].Nodes)-1)
                        
                number_buses_assigned_to_pickup[n] += 1
                fractional_buses_assigned_to_pickup[n] += 1/(len(dict_of_routes[mychoice[1]].Nodes)-1)
                fractional_buses_assigned_to_pickup[existing_node] -= 1/(len(dict_of_routes[mychoice[1]].Nodes)-1)
                print('added %s' % n)
                uncovered_pickup.remove(n)
            else:
                print('error')
    '''
    estimated_shelter_load = {sh: 0 for sh in list_of_shelters}
    for sh in list_of_shelters:
        for r in bus_route_assignment.keys():
            shN = bus_route_assignment[r][0]
            nodes = bus_route_assignment[r][1]
            if shN == sh:   
                for n in nodes:
                    fraction_allocated_to_node = 1/len(nodes)
                    num_buses_serving_node = fractional_buses_assigned_to_pickup[n]
                    fraction_allocated_to_node / num_buses_serving_node
                    estimated_shelter_load[sh] += pickup_demand[n] * modelConfig.PEOPLE_PER_AGENT * fraction_allocated_to_node / num_buses_serving_node
    '''
    bus_trips = InitializeBusTrips(dict_of_routes, bus_route_assignment, list_of_buses, list_of_trips)

    modelParameters.BUS = {k: bus_route_assignment[k] for k in bus_route_assignment.keys()}
    modelParameters.BUSROUTES = {k: dict_of_routes[k] for k in dict_of_routes.keys()}
    modelParameters.TRANSFERROUTES = {k: dict_of_transfers[k] for k in dict_of_transfers.keys()}
    modelParameters.BUSTRIPS = {k: bus_trips[k] for k in bus_trips.keys()}
    modelParameters.ADJUSTED_CAPACITY = {k: adjusted_capacity[k] for k in adjusted_capacity.keys()}

    route_list, dictWalkTimes = BuildRoutes(G, modelData, modelParameters)
    displayMap(G, modelConfig, modelData, modelParameters, route_list, 'bus routes')
    
    DoMoreRuns = True
    while DoMoreRuns == True:
        
        
    
        bus_trips = InitializeBusTrips(dict_of_routes, bus_route_assignment, list_of_buses, list_of_trips)
    
        modelParameters.BUS = {k: bus_route_assignment[k] for k in bus_route_assignment.keys()}
        modelParameters.BUSROUTES = {k: dict_of_routes[k] for k in dict_of_routes.keys()}
        modelParameters.TRANSFERROUTES = {k: dict_of_transfers[k] for k in dict_of_transfers.keys()}
        modelParameters.BUSTRIPS = {k: bus_trips[k] for k in bus_trips.keys()}
        modelParameters.ADJUSTED_CAPACITY = {k: adjusted_capacity[k] for k in adjusted_capacity.keys()}

        #route_list, dictWalkTimes = BuildRoutes(G, modelData, modelParameters)
        
        #for sh in modelData.Shelters.keys():
        #    modelData.Shelters[sh].Capacity -= lastRunsFinishCapacity[sh]
        
        ###############################################################################
        ###                            RU N EXPERIMENTS                              ###
        ###############################################################################
        RunExperiments(modelData, modelConfig, modelParameters, modelOutputs, busroute_add, list_of_buses, list_of_trips, bus_route_assignment)
        
        #lastRunsFinishCapacity = {}
        #for sh in modelData.Shelters.keys():
        #    lastRunsFinishCapacity[sh] = modelOutputs.ShelteredAgentsEach[1,sh][-1]
        
        
        
        
        title = COUNT_BUSES
        info = COUNT_BUSES
        data1 = [x for x in modelOutputs.SimulationEndTime.values()]
        boxplotSUMMARY[title] = data1
        infoSUMMARY[title] = info
        data2 = []
        data3 = {}
        for sh in modelOutputs.AgentWaitTimes.keys():
            if len(modelOutputs.AgentWaitTimes[sh]) > 0:
                data3[sh] = max(modelOutputs.AgentWaitTimes[sh])
            for x in modelOutputs.AgentWaitTimes[sh]:
                data2.append(x)
        boxplotWAIT[title] = data2
        
        maxwait_stop = max(data3, key=data3.get)
        
        
        v= []
        for k in modelOutputs.AgentWaitTimes.keys():
            for x in modelOutputs.AgentWaitTimes[k]:
                v.append(x)
        from pandas import DataFrame
        frame = DataFrame(v)
        #frame.describe()
        
        CountTotal = sum(x for x in v)
        CountAbove60 = sum(x for x in v if x <= 60)
        PercAbove60 = round(1-(CountAbove60 / CountTotal),4)
        CountAbove45 = sum(x for x in v if x <= 45)
        PercAbove45 = round(1-(CountAbove45 / CountTotal),4)
        CountAbove30 = sum(x for x in v if x <= 30)
        PercAbove30 = round(1-(CountAbove30 / CountTotal),4)
        
        
        outputData1[COUNT_BUSES] = (max(modelOutputs.SimulationEndTime.values())/60)
        outputData2[COUNT_BUSES] = [PercAbove60, PercAbove45, PercAbove30]
        outputData3[COUNT_BUSES] = [x/60 for x in modelOutputs.PackingTimes]
        outputData4[COUNT_BUSES] = [x/60 for x in modelOutputs.PercentageEvacuatedTime.values()]
        outputData5[COUNT_BUSES] = [x/60 for x in modelOutputs.ShelterArrivalTime]
        outputData6[COUNT_BUSES] = [x for x in modelOutputs.BusDwellTime[b] for b in modelParameters.BUS.keys()]
        outputData7[COUNT_BUSES] = [x for x in modelOutputs.RecordTransitTimes[s] for s in list_of_pickups]
        
        
        print('c = %s' % calibration)
        print('number buses = %d' % len(list_of_buses))
        
        
        if MODE_ADD_BUSES == True and len(required_number) > 0:
            newbus = 'B' + str(len(list_of_buses) + 1)
            if maxwait_stop != '':
                for b in bus_route_assignment.keys():
                    if maxwait_stop in bus_route_assignment[b][1]:
                        duplicate_bus = b
            bus_route_assignment[newbus] = bus_route_assignment[duplicate_bus]
            list_of_buses.append(newbus)
            COUNT_BUSES = required_number[0]
            required_number = required_number[slice(1,None)]
        else:
            DoMoreRuns = False
            


###############################################################################
###                              PLOT RESULTS                               ###
###############################################################################


sorted_dict = list(boxplotWAIT.items())
sorted_dict.sort()
boxplotWAIT = dict(sorted_dict)

sorted_dict = list(boxplotSUMMARY.items())
sorted_dict.sort() 
boxplotSUMMARY = dict(sorted_dict)

PlotShelterAllOccupancy(modelConfig, modelData, modelOutputs, initial_occupancy, '%')
PlotShelterEachOccupancy(modelConfig, modelParameters, modelData, modelOutputs, initial_occupancy, '%')
PlotWaitTimes(modelOutputs, info)

# make sure this pickup location ID is within simulated zone. 'P111' in Zone A.
PlotBusStopWaitTimeVsTime(modelConfig, modelOutputs, 'P111')


labels = {}
labels[0] = 'Zone ' + myzone + ' 100% Clearance Time'
labels[1] = 'Number of Buses'
labels[2] = '100% Clearance Time (hrs)'
CreateBoxPlot(boxplotSUMMARY, labels, 5, 1, [0,10], 60)

labels = {}
labels[0] = 'Zone ' + myzone + ' Waiting Times'
labels[1] = 'Number of Buses'
labels[2] = 'Waiting Time (hrs)'
CreateBoxPlot(boxplotWAIT, labels, 5, 1, [0,10], 60)

labels = {}
labels[0] = 'Zone ' + myzone + ' 80% Clearance Time'
labels[1] = 'Number of Buses'
labels[2] = '80% Clearance Time (hrs)'
CreateBoxPlot(outputData4, labels, 5, 1, [0,12], 1)

# temporary code to get output data for run with N=36 buses
v= []
for x in outputData7[36]:
    v.append(x)
from pandas import DataFrame
frame = DataFrame(v)
#frame.describe()

CountTotal = sum(x for x in v)
CountAbove60 = sum(x for x in v if x <= 60)
PercAbove60 = round(1-(CountAbove60 / CountTotal),4)
CountAbove45 = sum(x for x in v if x <= 45)
PercAbove45 = round(1-(CountAbove45 / CountTotal),4)
CountAbove30 = sum(x for x in v if x <= 30)
PercAbove30 = round(1-(CountAbove30 / CountTotal),4)
        

labels = {}
labels[0] = 'Zone ' + myzone + ' - Bus Dwell Time'
labels[1] = 'Number of Buses'
labels[2] = 'Dwell Time (minutes)'
CreateBoxPlot(outputData6, labels, 5, 30, [0,90], 1)

labels = {}
labels[0] = 'Zone ' + myzone + ' - Time Riding Bus'
labels[1] = 'Number of Buses'
labels[2] = 'Time Riding Bus (minutes)'
CreateBoxPlot(outputData7, labels, 5, 10, [0,120], 1)

# parameters: [# buses to show], [min_time, max_time], [min_y, max_y]
PlotArrivalDistributions(outputData3, outputData5, myzone, [10,20,30], [0,11], [0,1])

# Show %-above-wait-threshold graphic
PlotLines(modelConfig, outputData2)

###############################################################################
###                             OUTPUT RESULTS                              ###
###############################################################################


ShowSummaryStatistics(modelOutputs)
SaveActivityLog(modelConfig, modelOutputs, 1)
SaveSummaryReport(modelConfig, outputData2)

#PlotDistanceDemand(modelData, modelOutputs)


for sh in modelParameters.ADJUSTED_CAPACITY.keys():
    print(modelOutputs.ShelteredAgentsEach[3,sh][-1])

