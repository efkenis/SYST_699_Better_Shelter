# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 21:03:46 2022

@author: Developer
"""

from routing import GenerateBusNetwork, CalculateDemand
from model import Evacuation
from datetime import timedelta
import matplotlib.pyplot as plt
import numpy as np
from pandas import DataFrame
from csv import writer, QUOTE_ALL
from os import path, remove
from heuristics import InitializeBusTrips
import seaborn as sb


def RunExperiments(modelData, modelConfig, modelParameters, modelOutputs, modify_list, list_of_buses, list_of_trips, bus_route_assignment):
    
    MEASURE_PERCENT = 0.9
    modelOutputs.PercentageEvacuatedTime = {}
    modelOutputs.PackingTimes = []
    modelOutputs.ShelterArrivalTime = []
    
    initial_bus = {k : bus_route_assignment[k] for k in bus_route_assignment.keys()}
    initial_busroutes = {k : modelParameters.BUSROUTES[k] for k in modelParameters.BUSROUTES.keys()}
    initial_bustrips = {k : modelParameters.BUSTRIPS[k] for k in modelParameters.BUSTRIPS.keys()}

    
    N = modelConfig.NUMBER_OF_EXPERIMENTS
    PPA = modelConfig.PEOPLE_PER_AGENT
    time_limit = modelConfig.SIMULATION_TIME
    time_bin = 10
    
    demand = [modelData.Population[k].NumPeople for k in modelData.Population.keys()]
    # Calculate demand at each stop    (# agents only)    
    #demand, distance, distance_demand = CalculateDemand(modelData, modelParameters,modelConfig)
    total_evacuees = sum(demand)
    #modelOutputs.DistanceDemand = distance_demand
    
    dictActivityLog = {}
    dictOutput = {}
    dictOutput2 = {}
    dictTotalTime = {}
    dictTotalSheltered = {}
    dictTotalEachShelter = {}
    dictBusDwellTime = {b: [] for b in modelParameters.BUS.keys()}
    dictTransitTime = {s: [] for s in modelData.Stops.keys()}
    temp_dict = {}
    dictBusAssignments = {b:[] for b in modelParameters.BUS.keys()}
    dictBusShelters = {b:[] for b in modelParameters.BUS.keys()}
    dictOutput2 = {(k, tB): [] for k in modelData.Stops.keys() for tB in range(0,int(round(time_limit/time_bin,0)))}

    maxTime = 0
    experiments = range(1, N+1)
    for exp in experiments:
        finish_flag = False
        time_filled = 9999
        listTotalSheltered = []
        
        modelParameters.BUS = {k: initial_bus[k] for k in initial_bus.keys()}
        modelParameters.BUSROUTES = {k: initial_busroutes[k] for k in initial_busroutes.keys()}
        modelParameters.BUSTRIPS = {k: initial_bustrips[k] for k in initial_bustrips.keys()}

        
        #GenerateBusNetwork(modelConfig, modelData, modelParameters, modify_list)
        EVACUATION_MODEL = Evacuation(modelData, modelConfig, modelParameters)
        
        #logged_waiting_agents = {k: [] for k in modelData.Stops.keys()}
        percent_reached = False
        tB = 0
        t=0
        while not finish_flag and t <= time_limit and t <= time_filled+120:
            EVACUATION_MODEL.step()
            
            # GET TOTAL SHELTER OCCUPANCY COUNT OVER TIME
            num_evacuated_to_shelter = EVACUATION_MODEL.number_of_agents_at_shelter
            listTotalSheltered.append(PPA*num_evacuated_to_shelter)
            
            
            # GET INDIVIDUAL SHELTER OCCUPANCY COUNT OVER TIME
            for sh in modelParameters.ADJUSTED_CAPACITY.keys():
                num_agents = len(EVACUATION_MODEL.list_shelter_agents[sh])
                if (exp,sh) in dictTotalEachShelter.keys():
                    dictTotalEachShelter[exp,sh].append(PPA*num_agents)
                else:
                    dictTotalEachShelter[exp,sh] = [PPA*num_agents]
                    
            #finish_timestamp = modelConfig.START_TIME + timedelta(minutes=t)
            strTimeToFinish = str(timedelta(minutes=t))
            
            
            
            perc_complete = num_evacuated_to_shelter / total_evacuees
            if perc_complete >= MEASURE_PERCENT and percent_reached == False:
                modelOutputs.PercentageEvacuatedTime[exp] = t
                percent_reached = True
                
            
            #print('%s (%d) sheltered within %s' % (perc_complete, 
            #                                             num_evacuated_to_shelter, 
            #                                             strTimeToFinish))
                
            if num_evacuated_to_shelter >= total_evacuees and finish_flag == False:
                perc_complete = str(round(100*num_evacuated_to_shelter / total_evacuees, 1)) + '%'
                print('%s (%d) evacuation completed in %s' % (perc_complete, 
                                                             num_evacuated_to_shelter, 
                                                             strTimeToFinish))
                time_filled = t
                
                finish_flag = True
                dictTotalTime[exp] = t
                #dictOutput[exp] = EVACUATION_MODEL.agent_pickup_wait_times
            
            '''
            for b in modelParameters.BUS.keys():
                broute = modelParameters.BUS[b][1]
                for l in modelParameters.BUSROUTES.keys():
                    if broute == modelParameters.BUSROUTES[l][3]:
                        orig = modelParameters.BUSROUTES[l][1]
                        dest = modelParameters.BUSROUTES[l][2]
                        
                        if orig in modelData.Stops.keys() and orig not in dictBusAssignments[b]:
                            dictBusAssignments[b].append(orig)
                        if dest in modelData.Stops.keys() and dest not in dictBusAssignments[b]:
                            dictBusAssignments[b].append(dest)
                        if orig in modelData.Shelters.keys() and orig not in dictBusShelters[b]:
                            dictBusShelters[b].append(orig)
                        if dest in modelData.Shelters.keys() and dest not in dictBusShelters[b]:
                            dictBusShelters[b].append(dest)
            '''
            t += 1
            
        #print(modelParameters.BUS['B1'])
        #print(modelParameters.BUS['B5'])
        dictActivityLog[exp] = [EVACUATION_MODEL.activity_log_labels] + EVACUATION_MODEL.activity_log
        dictTotalSheltered[exp] = listTotalSheltered
        
        for b in modelParameters.BUS.keys():
            for x in EVACUATION_MODEL.BusDwellTime[b]:
                dictBusDwellTime[b].append(x)
        #if num_evacuated_to_shelter < total_evacuees:
        #    print('error')
        #    break
        
        for x in EVACUATION_MODEL.RecordPackingTimes:
            modelOutputs.PackingTimes.append(x)
        
        for x in EVACUATION_MODEL.RecordShelterArrivals:
            modelOutputs.ShelterArrivalTime.append(x)
        
        all_arrival_times = EVACUATION_MODEL.agent_arrival_time
        all_wait_times = EVACUATION_MODEL.agent_pickup_wait_times
        time_limit = modelConfig.SIMULATION_TIME
        
        for (s,e) in EVACUATION_MODEL.RecordTransitTimes.keys():
            dictTransitTime[s].append(EVACUATION_MODEL.RecordTransitTimes[s,e])
            #if EVACUATION_MODEL.RecordTransitTimes[s,e] > 120:
                #print('%s from %s dropped off late.' % (e, s))
            
            
        for tB in range(0,int(round(time_limit/time_bin,0))):
            start = tB * time_bin
            end = (tB + 1) * time_bin
            timerange = list(range(start, end))
            
            for s in modelData.Stops.keys():
                for agent in all_arrival_times[s].keys():
                    if all_arrival_times[s][agent] in timerange:
                        dictOutput2[s, tB].append(all_wait_times[s][agent])
                          
            
            
            
        temp_dict = {}
        temp_dict = EVACUATION_MODEL.agent_pickup_wait_times
        temp_dict = {k : [x for x in temp_dict[k].values()] for k in temp_dict.keys()}
        if exp == 1:
            dictOutput = {k: [] for k in modelData.Stops.keys()}
        for k in temp_dict.keys():
            for x in temp_dict[k]:
                dictOutput[k].append(x)
                
        if t > maxTime:
            maxTime = t

        modelOutputs.ActivityLog = dictActivityLog
        modelOutputs.AgentWaitTimes = dictOutput
        modelOutputs.SimulationEndTime = dictTotalTime
        modelOutputs.SimulationMaxTime = maxTime
        modelOutputs.ShelteredAgentsAll = dictTotalSheltered
        modelOutputs.ShelteredAgentsEach = dictTotalEachShelter
        modelOutputs.BusAssignmentList = dictBusAssignments
        modelOutputs.BusShelterList = dictBusShelters
        modelOutputs.AgentWaitTimesVsTime = dictOutput2
        modelOutputs.BusDwellTime = dictBusDwellTime
        modelOutputs.RecordTransitTimes = dictTransitTime

def SaveActivityLog(modelConfig, modelOutputs, exp):
    dir_activity_log_file = modelConfig.OUTPUT_DIRECTORY + '/activity_log.csv'
    if path.exists(dir_activity_log_file):
      remove(dir_activity_log_file)
    with open(dir_activity_log_file, 'w', newline='') as myfile:
         wr = writer(myfile, quoting=QUOTE_ALL)
         wr.writerows(modelOutputs.ActivityLog[exp])

    
def ShowSummaryStatistics(modelOutputs):
    # Summary statistics of Total Evacuation Time
    listData = [round(x/60,2) for x in modelOutputs.SimulationEndTime.values()]
    frame = DataFrame(listData)
    frame.columns = ['Total Evacuation Time (hrs)']
    print(frame.describe())
    
def SaveSummaryReport(modelConfig, outputData2):
    
    buslist = [[b,outputData2[b][0],outputData2[b][1],outputData2[b][2]] for b in outputData2.keys()]
        
    dir_activity_log_file = modelConfig.OUTPUT_DIRECTORY + '/summary_report.csv'
    if path.exists(dir_activity_log_file):
      remove(dir_activity_log_file)
    with open(dir_activity_log_file, 'w', newline='') as myfile:
         wr = writer(myfile, quoting=QUOTE_ALL)
         wr.writerows(buslist)
    
    
def CreateBoxPlot(boxplotDATA, labels, xincrement, yincrement, yrange, units):
    temp_labels = []
    i=min(boxplotDATA.keys())
    for v in boxplotDATA.keys():
        if i % xincrement == 0:
            temp_labels.append(v)
        else:
            temp_labels.append("")
        i += 1
    
    fig, ax = plt.subplots()
    data = {k: [x/units for x in boxplotDATA[k]] for k in boxplotDATA.keys()}
    ax.boxplot(data.values(), flierprops={'marker': '.', 'markersize': 2})
    ax.set_xticks(np.arange(1,len(temp_labels)+1))
    ax.set_xticklabels(temp_labels, size=14, rotation=0)
    ax.set_yticks(np.arange(yrange[0],yrange[len(yrange)-1]+1, yincrement))
    ax.set_yticklabels(np.arange(yrange[0],yrange[len(yrange)-1]+1, yincrement), size=14, rotation=0)
    mytitle = labels[0]
    ax.set_title(mytitle, size=18)
    ax.set_xlabel(labels[1], size=16)
    ax.set_ylabel(labels[2], size=16)
    ax.set_ylim(yrange)
    ax.grid(True)
    fig.show()
    


def PlotBusStopWaitTimeVsTime(modelConfig, modelOutputs, stop_name):
    # Print Graph of Shelter Occupancy vs. Time (minutes)
    
    
    time_limit = modelOutputs.SimulationMaxTime
    time_bin = 10
    
    temp_dict = {}
    for tB in range(0,int(round(time_limit/time_bin,0))):
        temp_dict[tB*time_bin] = [x for x in modelOutputs.AgentWaitTimesVsTime[stop_name, tB]]
    
    # BOX-WHISKER PLOT OF WAIT TIMES PER LOCATION {location : [wait times]}
    fig, ax = plt.subplots()
    ax.boxplot(temp_dict.values())
    ax.set_xticklabels(temp_dict.keys(), size=14, rotation=90)
    ax.set_title('Evacuee Wait Time', size =14)
    ax.set_xlabel('Evacuation Time (minutes)')
    ax.set_ylabel('Wait Time (minutes)')
    ax.set_ylim([0,120])
    fig.show()
    
    
def PlotLines(modelConfig, outputData):
    
    temp_dict = {k: outputData[k] for k in outputData.keys()}
    if 'header' in temp_dict.keys():
        temp_dict.pop('header')
    xaxis = [x for x in temp_dict.keys()]
    v0 = [100*temp_dict[v][0] for v in temp_dict.keys()]
    v1 = [100*temp_dict[v][1] for v in temp_dict.keys()]
    v2 = [100*temp_dict[v][2] for v in temp_dict.keys()]
    
    plt.plot(xaxis, v0, color='blue', label = '>60 minutes')
    plt.plot(xaxis, v1, color='purple', label = '>45 minutes')
    plt.plot(xaxis, v2, color='green', label = '>30 minutes')
    plt.title("% Wait Times Exceeded Threshold", size=18)
    plt.xlabel("Number of Buses", size=16)
    plt.ylabel("% Exceeded Threshold", size=16)
    plt.legend(loc = 'upper right', fontsize = 14)
    plt.ylim([0,100])
    plt.show()
    
    
    
    
def PlotShelterAllOccupancy(modelConfig, modelData, modelOutputs, adjustShelterCapacity, count_mode):
    # Print Graph of Shelter Occupancy vs. Time (minutes)
        
    maxCapacity = sum(modelData.Shelters[sh].Capacity for sh in modelData.Shelters.keys())
    maxTime = modelOutputs.SimulationMaxTime
    time = np.arange(0,maxTime)
    N = modelConfig.NUMBER_OF_EXPERIMENTS
    experiments = range(1, N+1)
    for exp in experiments:
        y = []
        experiment_data = modelOutputs.ShelteredAgentsAll[exp]
        for t in time:
            
            adj = sum(adjustShelterCapacity.values())
            if t < len(experiment_data):
                if count_mode == '#':
                    val = modelOutputs.ShelteredAgentsAll[exp][t] + adj
                elif count_mode == '%':
                    val = 100*(modelOutputs.ShelteredAgentsAll[exp][t] + adj)/maxCapacity
                y.append(val)
            else:
                if count_mode == '#':
                    y.append(max(experiment_data) + adj)
                elif count_mode == '%':
                    y.append(100*(max(experiment_data) + adj)/maxCapacity)
        plt.plot(time, y)
    plt.title("Shelter Occupancy (%s) vs. Time" % count_mode, size=14)
    plt.xlabel("Evacuation Time (minutes)", size=14)
    plt.ylabel("Total %s Sheltered" % count_mode, size=14)
    if count_mode == '%':
        plt.ylim([0,100])
    plt.show()
    
    
    
def PlotShelterEachOccupancy(modelConfig, modelParameters, modelData, modelOutputs, adjustShelterCapacity, count_mode):
    # Line graphs of individual shelter occupancy vs. time
    colors_list = ['red', 'blue', 'green', 'purple', 'orange', 'navy', 'indigo', 'peru', 'cyan', 'crimson', 'cadetblue', 'olive', 'lime']
    colors_dict = {}
    x = 0
    for sh in modelData.Shelters.keys():
        colors_dict[sh] = colors_list[x]
        x += 1
    maxTime = modelOutputs.SimulationMaxTime
    time = np.arange(0,maxTime)
    N = modelConfig.NUMBER_OF_EXPERIMENTS
    experiments = range(1, N+1)
    for exp in experiments:
        for sh in modelParameters.ADJUSTED_CAPACITY.keys():
            y = []
            adj = adjustShelterCapacity[sh]
            shCapacity = modelData.Shelters[sh].Capacity + adj
            experiment_data = modelOutputs.ShelteredAgentsEach[exp,sh]
            if experiment_data[len(experiment_data)-1] > 0:
                for t in time:
                    if t < len(experiment_data):
                        if count_mode == '#':
                            val = modelOutputs.ShelteredAgentsEach[exp,sh][t] + adj
                        elif count_mode == '%':
                            val = 100*(modelOutputs.ShelteredAgentsEach[exp,sh][t] + adj)/shCapacity
                        y.append(val)
                    else:
                        if count_mode == '#':
                            y.append(max(experiment_data) + adj)
                        elif count_mode == '%':
                            y.append(100*(max(experiment_data) + adj)/shCapacity)
                if exp == 1:
                    plt.plot(time, y, color = colors_dict[sh], label = 'Tier %d - %s' % (modelData.Shelters[sh].Tier, modelData.Shelters[sh].Name))
                else:
                    plt.plot(time, y, color = colors_dict[sh])
    plt.legend(loc = 'upper left', fontsize = 12)
    plt.title("Shelter Occupancy (%s) vs. Time" % count_mode, size=14)
    plt.xlabel("Evacuation Time (minutes)", size=14)
    plt.ylabel("Total %s Sheltered" % count_mode, size=14)
    
    if count_mode == '%':
        plt.ylim([0,100])
    plt.show()
    
    
def PlotDistanceDemand(modelData, modelOutputs):
    
    #countBusesPerStop = {s : 0 for s in modelData.Stops.keys()}
    #assignments = modelOutputs.BusAssignmentList
    #for s in modelData.Stops.keys():
    #    for b in assignments.keys():
    #        if assignments[b] == s:
    #            countBusesPerStop[s] += 1
            
    
    data = modelOutputs.Demand
    ax1 = []
    ax2 = []
    for d in data.keys():
        ax1.append(d)
        ax2.append(data[d])
    plt.bar(ax1, ax2, width=0.7, bottom=50, align='center')
    plt.title('Demand x Distance Per Pickup Point')
    plt.xticks(ax1, size=14, rotation=90)
    plt.xlabel('Pickup Point', fontsize=15)
    plt.ylabel('Demand x Distance', fontsize=15)
    plt.show()
    
    
def PlotWaitTimes(modelOutputs, title):
    # BOX-WHISKER PLOT OF WAIT TIMES PER LOCATION {location : [wait times]}
    fig, ax = plt.subplots()
    
    data = modelOutputs.AgentWaitTimes
    datasort = {}
    k=0
    for k in data.keys():
        if len(data[k]) > 0:
            datasort[k] = data[k]

    ax.boxplot(datasort.values())
    ax.set_xticklabels(datasort.keys(), size=14, rotation=90)
    ax.set_title('Pickup Wait Times', size = 14)
    ax.set_xlabel('Pickup Location', size=14)
    ax.set_ylabel('Wait Time (minutes)', size=14)
    ax.set_ylim([0,120])
    fig.show()
    

def PlotArrivalDistributions(outputData3, outputData5, myzone, buscounts, xrange, yrange):
    # ARRIVAL DISTRIBUTION
    sb.set()
    sb.set_style("whitegrid")
    plotdata = []
    legendkeys = []
    for k in outputData3.keys():
        for x in outputData3[k]:
            plotdata.append(x)
    legendkeys.append('Pickup Arrivals')
    ax = sb.kdeplot(plotdata, shade = True, color = 'gray', label='Rayleigh Distribution')
    
    ocean = '#668abe'
    blue = '#2f00ff'
    seaweed = '#79cfb8'
    sky = '#89cff0'
    black = '#222222'
    brick = '#d54240'
    purple = '#cc66aa'
    lightred = '#fd6159'
    medgreen = '#0d8767'
    
    palette = [purple, medgreen, blue ]
    linestyle = ['dotted','dashed','solid']
    i=0
    for case in outputData5.keys():
        if case in buscounts:
            legendkeys.append('Shelter Arrivals: %d buses' % case)
            plotdata2 = []
            for x in outputData5[case]:
                    plotdata2.append(x)
            ax = sb.distplot(plotdata2, color = palette[i], kde_kws = {'linestyle': linestyle[2]}, hist=False, label='%d buses' % case)
            #ax = sb.kdeplot(plotdata2, shade = True, color = 'b')
            i += 1
            
    plt.legend(legendkeys, fontsize=14)
    plt.title('Zone ' + str(myzone) + ' Evacuation Pickup & Shelter Arrival Times', size=14)
    plt.xlabel('Evacuation Time (hrs)', fontsize=14)
    plt.ylabel('Arrival Density', fontsize=14)
    plt.xlim(xrange)
    plt.ylim(yrange)
    #plotting the graph
    plt.show()
