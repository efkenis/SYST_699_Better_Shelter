# -*- coding: utf-8 -*-
"""
Created on Thu Mar 31 14:36:32 2022

@author: Developer
"""

from mesa import Agent

from numpy import random


            
#################################################################################
#################################################################################
#################################################################################
#################################################################################
#################################################################################
            
class Bus(Agent):
    def __init__(self, name, model, trips, modelConfig):
        super().__init__(name, model)
        self.name = name
        self.model = model
        
        self.number_of_agents_on_bus = 0 
        self.iTimeOffloading = 0
        self.iTimeLoading = 0
        
        self.number_agents_picked_up = 0
        self.total_bus_loading_time = 0
        
        self.TRIPS = trips
        self.iTrip = 0
        self.CURRENT_TRIP = self.TRIPS[1]
        
        self.LOADTIME_MULTIPLIER = modelConfig.TIME_PER_AGENT_LOAD_BUS
        self.BUS_CAPACITY = modelConfig.BUS_CAPACITY
        self.ADJUSTED_BUS_CAPACITY = modelConfig.ADJUSTED_BUS_CAPACITY
        self.PEOPLE_PER_AGENT = modelConfig.PEOPLE_PER_AGENT
        
        self.iDwellTime = 0
        
        self._at_shelter = True
        self._in_transit = False
        self._at_busstop = False
        
        
        #self.original_assignment = trips[1][1]
        self.location = self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes[0] 
        
        self.my_waitlist = {}
        for n in self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes:
            if n not in self.model.SHELTERS.keys():
                self.my_waitlist[n] = self.model.number_of_agents_waiting[n]
        
        self.iTimeTransit = 0
        self.iRouteLeg = 1
        
        self.origin = self.location
        self.destination = self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes[1]
        
        
        log_data(self, self.name, 1, 'initialized')
    
    # This function determines bus offloading activity during stop at a shelter
    def shelter(self, OFFLOAD_TIME, bus_trips):
        
        # UPDATE BUS STATUS TRACKERS
        self._at_shelter = True
        self._in_transit = False
        self._at_busstop = False
        self.iTimeTransit = 0 
        self.iTimeLoading = 0
        
        # BUS OFF-LOADING AT SHELTER
        if self.iTimeOffloading < OFFLOAD_TIME:
            
            # ITERATE TIME DURING OFF-LOAD AT SHELTER
            self.iTimeOffloading += 1
            
        # BUS DEPARTS SHELTER
        else:
            
            #print('%s departs from %s at %d' % (self.name, self.origin, self.model.time_counter))
            # UPDATE BUS STATUS TRACKERS
            self._at_shelter = False        # CHANGED
            self._in_transit = True         # CHANGED
            self._at_busstop = False
            self.iTimeTransit = 0 
            self.iTimeLoading = 0
            
            # RESET COUNTERS
            #self.occupants = 0              # All seats available
            self.iTimeOffloading = 0        # Off-load time counter reset
            self.iRouteLeg = 1          # Route leg 1
            self.iTrip += 1
            self.CURRENT_TRIP = self.TRIPS[self.iTrip]
            
            # SET NEW ORIGIN/DESTINATION
            #self.origin = modelParameters.bus_trips[self.iTrip][0]         # shelter
            
            myroute = self.CURRENT_TRIP.Route
            
            if myroute in self.model.BUSROUTES.keys():
                self.origin = self.model.BUSROUTES[myroute].Nodes[0]
                self.destination = self.model.BUSROUTES[myroute].Nodes[1]
            else:
                self.origin = self.model.TRANSFERROUTES[myroute].Nodes[0]
                self.destination = self.model.TRANSFERROUTES[myroute].Nodes[1]
                
            '''
            origin_shelter_capacity = self.model.SHELTER_CAPACITY[self.origin]
            
            # Current lists and stats for shelter occupancy
            # Shelter space is counted by individual people, not agents
            # (Agents = "groups" of people)
            current_list_shelter_agents = self.model.list_shelter_agents[self.origin]
            current_number_shelter_agents = len(current_list_shelter_agents)
            current_number_shelter_individuals = current_number_shelter_agents * self.PEOPLE_PER_AGENT
            current_shelter_space = origin_shelter_capacity - current_number_shelter_individuals
            '''
            #N = self.number_of_agents_on_bus * self.PEOPLE_PER_AGENT
            #if self.destination == 'SH12':
                #print('%s: %d, %d' % (self.origin, self.PEOPLE_PER_AGENT * self.number_of_agents_on_bus, current_shelter_space))
                
    
    # This function determines bus activity during transit between nodes
    def transit(self, bus_routes):
        
        # UPDATE BUS STATUS TRACKERS
        self._at_shelter = False
        self._in_transit = True
        self._at_busstop = False
        self.iTimeLoading = 0
        
        # RESET PICKUP QUANTITY/TIME
        self.number_agents_picked_up = 0
        self.total_bus_loading_time = 0
        
        # RESET COUNTERS
        self.iTimeLoading = 0
        
        
        # CALCULATE TRANSIT TIME
        #print(self.name)
        #print(bus_routes)
        iLength = self.iRouteLeg-1 # if iRouteLeg=1 (first non-shelter node) then choose 0th length
        myroute = self.CURRENT_TRIP.Route
        
        if myroute in self.model.BUSROUTES.keys():
            transit_time = self.model.BUSROUTES[myroute].Lengths[iLength]
        else:
            transit_time = self.model.TRANSFERROUTES[myroute].Length[iLength]
            
        #current_destination = self.model.BUSROUTES[myroute].Nodes[self.iRouteLeg]
        #self.destination  = current_destination
        
        if self.iTrip == 1 and self.iRouteLeg == 1:
            mycount = 0
            for b in self.model.BUS.keys():
                if self.model.BUS[b][2] == myroute:
                    mycount += 1
            
            if mycount > 1:        
                transit_time = random.uniform(2,2, size=1)
            elif mycount == 1:
                transit_time = 2
            
        #if self.ADJUSTED_BUS_CAPACITY == self.number_of_agents_on_bus: # bus full
        #    if self.destination not in self.model.SHELTERS.keys():
        #        transit_time = 2 # this is an approximation of the fact that buses
                                # will return to shelter once filled, rather than
                                # proceeding to the next stop.
                                # Future modeling should replace this with better
                                # logic.
                
                
        MinDelay = self.model.MinDelay
        MaxDelay = self.model.MaxDelay
        if self.destination in self.model.LastVisit.keys():
            time_since_last_visit = self.model.time_counter - self.model.LastVisit[self.destination]
            time_left_in_journey = transit_time - self.iTimeTransit
            if time_since_last_visit <= MinDelay:
                if time_left_in_journey < MinDelay - time_since_last_visit and self.iDwellTime <= MaxDelay:
                    self.iTimeTransit -= 1
                    self.iDwellTime += 1
            
            
            
            '''
        if self.destination not in self.model.SHELTERS.keys(): # headed to pickup
            nodes = self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes
            
            
            if sum(self.my_waitlist.values()) == 0: # nobody present at any pickup
                
                if self.destination == nodes[1]: #headed to first stop
                    
                    # Stall in proximity to destination
                    if self.iTimeTransit >= transit_time - 4: #nominal 4-minute buffer
                        self.iTimeTransit -= 1      # stall if nobody present
                    
                #else:           #headed to second stop
                #    if self.iTimeTransit >= transit_time - 4: #nominal 4-minute buffer
                #        self.iTimeTransit -= 1
            
            
        #for n in self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes:
        #    if n not in self.model.SHELTERS.keys():
        #        self.my_waitlist[n] = self.model.number_of_agents_waiting[n]
        
            '''
        #print(bus_routes)
        # ITERATE TIME DURING TRANSIT
        if self.iTimeTransit < transit_time:
            
            self.iTimeTransit += 1
            self.location = 'in transit'
            
        # BUS ARRIVED AT STOP OR SHELTER
        else:
            
            # UPDATE BUS STATUS TRACKER / RESET TRANSIT TIME COUNTER
            self._in_transit = False
            self.iTimeTransit = 0
            
            self.location = self.destination
            
            # IF ARRIVED AT SHELTER...
            # ASSUME SHELTER ID BEGINS WITH 'SH'!
            if self.destination[:2] == 'SH':      ### CHANGE HOW THIS CHECK WORKS...
                
                # UPDATE BUS STATUS TRACKER
                self._at_shelter = True
                
                # Remember that shelter "capacity" means all individuals associated
                # with the agents (number of agents * individuals per agent)
                SHELTER_CAPACITY = self.model.SHELTER_CAPACITY[self.destination]
                
                # Current lists and stats for shelter occupancy
                # Shelter space is counted by individual people, not agents
                # (Agents = "groups" of people)
                current_list_shelter_agents = self.model.list_shelter_agents[self.destination]
                current_number_shelter_agents = len(current_list_shelter_agents)
                current_number_shelter_individuals = current_number_shelter_agents * self.PEOPLE_PER_AGENT
                current_shelter_space = SHELTER_CAPACITY - current_number_shelter_individuals
                
                # Current lists and stats for bus occupancy
                current_list_agents_in_bus = self.model.list_agents_in_bus[self.name]
                current_number_agents_in_bus = len(current_list_agents_in_bus)
                current_number_individuals_in_bus = current_number_agents_in_bus * self.PEOPLE_PER_AGENT
                
                #if self.ROUTE[self.iRouteLeg][3] == 'Transfer':
                #    print('%s transfering to shelter with %d occupants' % (self.name, current_number_individuals_in_bus))
                
                #print('%d vs %d' % (current_number_individuals_in_bus,current_shelter_space))
                if current_number_individuals_in_bus >= current_shelter_space:
                    iter_amount = 0
                    while iter_amount * self.PEOPLE_PER_AGENT < current_shelter_space:
                        iter_amount += 1
                    if current_shelter_space % self.PEOPLE_PER_AGENT == 0:
                        number_agents_to_drop_off = iter_amount
                    else:
                        number_agents_to_drop_off = iter_amount-1
                        
                    list_agents_to_drop_off = current_list_agents_in_bus[:number_agents_to_drop_off]
                    
                    
                else:
                
                    number_agents_to_drop_off = current_number_agents_in_bus
                    list_agents_to_drop_off = current_list_agents_in_bus

                for a in list_agents_to_drop_off:
                    total_time_riding_bus = self.model.time_counter - self.model.RecordTransitTimes[a.split('_')[0], a]
                    self.model.RecordTransitTimes[a.split('_')[0], a] = total_time_riding_bus

                number_individuals_to_drop_off = self.PEOPLE_PER_AGENT * number_agents_to_drop_off
                
                # UPDATE ROSTER OF SHELTERED AGENTS (this shelter only)
                self.model.list_shelter_agents[self.destination] = current_list_shelter_agents + list_agents_to_drop_off
                updated_number_shelter_agents = len(self.model.list_shelter_agents[self.destination])
                updated_number_shelter_individuals = self.PEOPLE_PER_AGENT * updated_number_shelter_agents
                
                # LOG ARRIVAL TIMES
                for a in list_agents_to_drop_off:
                    self.model.RecordShelterArrivals.append(self.model.time_counter)
                
                # UPDATE ROSTER OF SHELTERED AGENTS ACROSS ALL SHELTERS
                list_overall_shelter_agents = self.model.roster_all_shelter_agents
                self.model.roster_all_shelter_agents = list_overall_shelter_agents + list_agents_to_drop_off
                
                self.model.number_of_agents_at_shelter = len(self.model.roster_all_shelter_agents)
                #self.model.number_of_agents_at_shelter += number_agents_to_drop_off
                
                #######################  ACTIVITY LOG  ########################
                log_data(self, self.name, number_individuals_to_drop_off, 'dropped off')
                log_data(self, self.destination, updated_number_shelter_individuals, 'shelter capacity used')
                ###############################################################
                
                # Update bus occupancy
                self.model.list_agents_in_bus[self.name] = current_list_agents_in_bus[slice(number_agents_to_drop_off,None)]
                self.number_of_agents_on_bus = len(self.model.list_agents_in_bus[self.name])
                #self.number_of_agents_on_bus = self.number_of_agents_on_bus - number_agents_to_drop_off
                
                if self.number_of_agents_on_bus > 0:
                    #print(current_shelter_space)
                    #print(SHELTER_CAPACITY)
                    #print('Shelter capacity exceeded. Dropping off %d' % number_agents_to_drop_off * self.PEOPLE_PER_AGENT)
                    
                    current_tier = 1
                    available_shelters = {}
                    finishflag = False
                    while finishflag == False:
                        for sh in self.model.SHELTERS.keys():
                            if self.model.SHELTERS[sh].Tier == current_tier:
                                sh_list_shelter_agents = self.model.list_shelter_agents[sh]
                                sh_number_shelter_agents = len(sh_list_shelter_agents)
                                sh_number_shelter_individuals = sh_number_shelter_agents * self.PEOPLE_PER_AGENT
                                sh_shelter_space = self.model.SHELTER_CAPACITY[sh] - sh_number_shelter_individuals
                                
                                if sh_shelter_space >= self.number_of_agents_on_bus * self.PEOPLE_PER_AGENT:
                                    available_shelters[sh] = sh_shelter_space
                        if len(available_shelters) == 0:
                            current_tier += 1
                        else:
                            finishflag=True
                        
                    #print('%s switching from' % self.name)
                    #print(self.model.BUSROUTES[myroute].Nodes)
                    #print('to')
                    chosen_shelter = max(available_shelters, key=available_shelters.get)
                    
                    #print('Proceeding to %s with %d space' % (chosen_shelter, sh_shelter_space))

                    if myroute in self.model.BUSROUTES.keys():
                        current_nodes = [n for n in self.model.BUSROUTES[myroute].Nodes]
                        current_shelter = current_nodes[0]
                        current_nodes[0] = chosen_shelter
                        
                        
                        for tr in self.model.TRANSFERROUTES.keys():
                            shelters = self.model.TRANSFERROUTES[tr].Nodes
                            #print(shelters)
                            #print(chosen_shelter)
                            if shelters[0] == current_shelter and shelters[1] == chosen_shelter:
                                new_transfer = tr
                        
                                
                        for k in self.model.BUSROUTES.keys():
                            if self.model.BUSROUTES[k].Nodes == current_nodes:
                                new_route = k
                               
                        self.TRIPS[self.iTrip + 1].Route = new_transfer
                        k = self.iTrip + 2
                        while k < len(self.TRIPS):
                            self.TRIPS[k].Route = new_route
                            k += 1
                    else:
                        current_nodes = [n for n in self.model.TRANSFERROUTES[myroute].Nodes]
                        current_shelter = self.location
                        current_nodes[0] = current_shelter
                        current_nodes[1] = chosen_shelter
                        
                        
                        for tr in self.model.TRANSFERROUTES.keys():
                            shelters = self.model.TRANSFERROUTES[tr].Nodes
                            #print(shelters)
                            #print(chosen_shelter)
                            if shelters[0] == current_shelter and shelters[1] == chosen_shelter:
                                new_transfer = tr
                        
                                
                        for k in self.model.BUSROUTES.keys():
                            if self.model.BUSROUTES[k].Nodes[0] == chosen_shelter:
                                mynodes = self.model.BUSROUTES[self.TRIPS[self.iTrip+2].Route].Nodes
                                if len(mynodes) == 2:
                                    if len(self.model.BUSROUTES[k].Nodes) == 2 and mynodes[1] == self.model.BUSROUTES[k].Nodes[1]:
                                        new_route = k
                                else:
                                    if len(self.model.BUSROUTES[k].Nodes) == 3 and mynodes[1] == self.model.BUSROUTES[k].Nodes[1] and mynodes[2] == self.model.BUSROUTES[k].Nodes[2]:
                                        new_route = k
                                        
                        self.TRIPS[self.iTrip + 1].Route = new_transfer
                        k = self.iTrip + 2
                        while k < len(self.TRIPS):
                            self.TRIPS[k].Route = new_route
                            k += 1
                        
                
            # UPON ARRIVAL AT STOP... (one step, then move to stop() function)
            # ASSUME STOP ID DOES *NOT* BEGIN WITH 'SH'
            else:
                
                # UPDATE BUS STATUS TRACKER
                self._at_busstop = True
                
                self.model.BusDwellTime[self.name].append(self.iDwellTime)
                
                self.model.LastVisit[self.destination] = self.model.time_counter
            
                # Update model queue: list of buses at stop
                #self.model.buses_available_at_stop[self.destination].append(self.name)
                
                # Measure bus stop queue size (# Evacuees)
                number_waiting_agents = self.model.number_of_agents_waiting[self.destination]
                
                #######################  ACTIVITY LOG  ########################
                number_waiting_individuals = self.PEOPLE_PER_AGENT * number_waiting_agents
                # bus stop queue size when bus arrives
                log_data(self, self.name, number_waiting_individuals, 'individuals waiting')
                ###############################################################
                
                
                # Measure bus available capacity
                number_agents_can_board = self.ADJUSTED_BUS_CAPACITY - self.number_of_agents_on_bus
                
                # Pick up as many people as possible, given available capacity
                if number_agents_can_board >= number_waiting_agents:
                    self.number_agents_picked_up = number_waiting_agents
                else:
                    self.number_agents_picked_up = number_agents_can_board
                self.number_of_agents_on_bus += self.number_agents_picked_up
                
                #if number_waiting_agents > 0:
                #    print('%d agents waiting at %s' % (number_waiting_agents, self.destination))
                #if self.number_agents_picked_up > 0:
                #    print('%s stops at %s and picks up %d out of %d' % (self.name, self.destination, self.number_agents_picked_up, number_waiting_agents))
                
                # UPDATE PICKUP QUEUE ENTITIES
                if self.number_agents_picked_up > 0:
                    
                    # ADD PICKUP_LIST TO BUS OCCUPANTS LIST
                    current_list_agents_in_bus = self.model.list_agents_in_bus[self.name]
                    
                    # Take N agents off front of queue
                    pickup_list = self.model.queue_agents_waiting_for_pickup[self.destination][:self.number_agents_picked_up]
                    
                    # Add N agents from wait queue to bus
                    self.model.list_agents_in_bus[self.name] = current_list_agents_in_bus + pickup_list
                    
                    # REMOVE PICKED UP AGENTS FROM BUS STOP QUEUE
                    self.model.queue_agents_waiting_for_pickup[self.destination] = self.model.queue_agents_waiting_for_pickup[self.destination][slice(self.number_agents_picked_up,None)]
                
                # Calculate time bus spends loading people at stop
                time_to_unload = 0
                for a in self.model.list_agents_in_bus[self.name]:
                    if 'wheelchair' in a:
                        time_to_unload += self.model.WHEELCHAIR_LOADTIME
                    else:
                        time_to_unload += self.LOADTIME_MULTIPLIER
                self.total_bus_loading_time = max(0, time_to_unload - self.iDwellTime)
                
                self.model.number_of_agents_waiting[self.destination] -= self.number_agents_picked_up
                
            self.iDwellTime = 0
            
            return
    
    # This function determines activity when the bus is at a stop
    def stop(self, bus_routes, number_agents_picked_up, loading_time):
        
        # RESET TRANSIT TIME COUNTER TO ZERO
        self.iTimeTransit = 0
        
        # ITERATE TIME DURING BUS STOP
        if self.iTimeLoading < loading_time:
            self.iTimeLoading += 1
            self.location = self.destination
            
        # BUS READY TO LEAVE
        else:
            
            # UPDATE BUS STATUS TRACKERS
            self._in_transit = True
            self._at_busstop = False
            
            # UPDATE NUMBER OF EVACUEES WAITING AT BUS STOP 
            ##self.model.number_of_agents_waiting[self.destination] -= pickup_amount
            
            # UPDATE LIST OF BUSES CURRENTLY AT STOP (remove this bus)
            #self.model.buses_available_at_stop[self.destination].remove(self.name)
            
            # UPDATE ROUTE COUNTER TO NEXT ROUTE LEG
            self.iRouteLeg += 1
            
            
            myroute = self.CURRENT_TRIP.Route
            if self.iRouteLeg >= len(self.model.BUSROUTES[myroute].Nodes):
                #print(bus_routes)
                # UPDATE BUS ORIGIN/DESTINATION
                self.origin = self.model.BUSROUTES[myroute].Nodes[self.iRouteLeg-1]
                self.destination = self.model.BUSROUTES[myroute].Nodes[0]
            else:
                self.origin = self.model.BUSROUTES[myroute].Nodes[self.iRouteLeg-1]
                self.destination = self.model.BUSROUTES[myroute].Nodes[self.iRouteLeg]
            
            number_individuals_to_pick_up = self.PEOPLE_PER_AGENT * number_agents_picked_up
            number_individuals_now_waiting = self.PEOPLE_PER_AGENT * self.model.number_of_agents_waiting[self.origin]
            #######################  ACTIVITY LOG  ########################
            # bus stop queue size on departure (new arrivals - bus pickups)
            log_data(self, self.name, number_individuals_to_pick_up, 'picked up')
            log_data(self, self.name, number_individuals_now_waiting, 'individuals waiting')
            ###############################################################
            
            #if self.name == 'B1':
                #print('...bus stop queue = ' + str(self.model.number_of_agents_waiting))
                
                #xStr = ''
                #for x in self.model.number_of_agents_waiting.keys():
                #    xStr = xStr + ', ' + str(self.model.number_of_agents_waiting[x])
                #    
                #print(str(self.now) + ': ' + str(xStr))
            
            return
    
    
    ### This step function determines bus activity at each simulation time step
    def step(self):
        
        self.my_waitlist = {}
        if self.CURRENT_TRIP.Route in self.model.BUSROUTES.keys():
            for n in self.model.BUSROUTES[self.CURRENT_TRIP.Route].Nodes:
                if n not in self.model.SHELTERS.keys():
                    self.my_waitlist[n] = self.model.number_of_agents_waiting[n]
        
        
        ### BUS PROCESSES EVACUEES AT SHELTER ###
        if self._at_shelter == True:
            
            time_to_unload = 0
            for a in self.model.list_agents_in_bus[self.name]:
                if 'wheelchair' in a:
                    time_to_unload += self.model.WHEELCHAIR_LOADTIME
                else:
                    time_to_unload += self.LOADTIME_MULTIPLIER
                    
            self.OFFLOAD_TIME = time_to_unload
            self.shelter(self.OFFLOAD_TIME, self.TRIPS)
        ### BUS IS IN TRANSIT BETWEEN NODES ###
        elif self._in_transit == True:
            self.transit(self.TRIPS)
            
        ### BUS IS LOADING EVACUEES AT A BUS STOP ###
        elif self._at_busstop == True:
            
            self.stop(self.TRIPS, self.number_agents_picked_up, self.total_bus_loading_time)
        
            


    
class Evacuee(Agent):
    def __init__(self, name, model, pack_time, walk_time, orig, destination):
        super().__init__(name, model)
        self.name = name
        self.model = model
        
        self.PACK_TIME = pack_time
        self.WALK_TIME = walk_time
        self.DESTINATION = destination
        
        self.location = orig
        
        # Time required to respond to evacuation order
        self._home = True
        self._packed = False
        self._arrived_at_busstop = False
        self._on_bus = False
        self._at_shelter = False
        self.time_packing = 0
        self.steps_taken = 0
        self._wait_location = 'NA'
    
    def home(self, pack_time):
        self._home = True
        self._packed = False
        self._arrived_at_busstop = False
        self._on_bus = False
        self._at_shelter = False
        if self.time_packing < pack_time:
            self.time_packing += 1
        else:
            self._packed = True
            return
        
    def walk(self, walk_time):
        self._home = False
        self._packed = True 
        self._arrived_at_busstop = False
        self._on_bus = False
        self._at_shelter = False
        self.steps_taken += 1
        self.location = 'heading to stop'
        if self.steps_taken < int(walk_time):
            self.steps_taken += 1
        else:
            self.model.agent_arrival_time[self.DESTINATION][self.name] = self.model.time_counter
            self.model.number_of_agents_waiting[self.DESTINATION] += 1
            self.model.queue_agents_waiting_for_pickup[self.DESTINATION].append(self.name)
            self.model.agent_pickup_wait_times[self.DESTINATION][self.name] = 0
            self._arrived_at_busstop = True
            return
    
    def wait(self, location):
        self._home = False
        self._packed = True
        self._arrived_at_busstop = True
        self._wait_location = location
        self._on_bus = False
        self._at_shelter = False
        self.location = self.DESTINATION
        
        # ITERATE SELF WAIT TIME AT BUS STOP
        self.model.agent_pickup_wait_times[self.DESTINATION][self.name] += 1
        
        # GET CURRENT QUEUE AT BUS STOP
        # CHECK IF SELF IN QUEUE (when bus arrives, it will take action to
        # remove self from pickup queue and add to bus queue)
        my_pickup_queue = self.model.queue_agents_waiting_for_pickup[self.DESTINATION]
        if self.name not in my_pickup_queue:
            self.model.RecordTransitTimes[self.location, self.name] = self.model.time_counter
            self._arrived_at_busstop = False
            self._wait_location = 'NA'
            self._on_bus = True
        else:
            return
        
        
    def in_transit(self):
        
        if self.name in self.model.roster_all_shelter_agents:
            self._wait_location = 'NA'
            self._on_bus = False
            self._at_shelter = True
            self.location = 'in transit'
        return
      
        
        
        
    def step(self):
        if self._home == True and self._packed == False:
            self.home(self.PACK_TIME)
        elif self._packed == True and self._arrived_at_busstop == False and self._on_bus == False and self._at_shelter == False:
            self.walk(self.WALK_TIME)
        elif self._arrived_at_busstop == True:
            self.wait(self.DESTINATION)
        elif self._on_bus == True:
            self.in_transit()
        elif self._at_shelter == True and not self.location == 'sheltered':
            self.location = 'sheltered'
            return


def log_data(self, entity_id, amount, activity):
    
    timestamp = self.model.time_counter
    
    if entity_id in self.model.BUS.keys():              ### I am a bus
        entity_name = entity_id
        location = self.location
        capacity = self.BUS_CAPACITY
        
    elif entity_id in self.model.SHELTERS.keys():       ### I am a shelter
        entity_name = self.model.SHELTERS[entity_id].Name
        location = entity_id
        capacity = self.model.SHELTER_CAPACITY[entity_id]
    
    else:                                               ### I am a person
        entity_name = entity_id
        location = self.location
        capacity = 'NA'
    
    if len(self.model.activity_log_labels) == 0:
        self.model.activity_log_labels = ['time', 'entity_id', 'entity_name', 'location', 'amount', 'capacity', 'activity']
    msg = [timestamp, entity_id, entity_name, location, amount, capacity, activity]
    self.model.activity_log.append(msg)
    
