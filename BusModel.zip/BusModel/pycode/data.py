# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 20:47:16 2022

@author: GMU
"""

from class_objects import modelData, WS, Population, BusStop, Shelter, Route, Bus, Polygon
#from os import path, mkdir
from pandas import ExcelFile


def compileInputData(EXCEL_WB):
    
    WS = ParseWorkbook(EXCEL_WB)
    modelData = compileModelData(WS)
    
    return modelData


def GetModelData(modelConfig):
    
    print('...Importing ' + str(modelConfig.INPUT_FILE_NAME))
    
    # Set file paths based on START.py user inputs
    dir_input = modelConfig.INPUT_DIRECTORY
    #dir_output = modelConfig.OUTPUT_DIRECTORY
        
    # Build Excel workbook object using pandas ExcelFile function
    EXCEL_WB = ExcelFile(dir_input + '\\' + modelConfig.INPUT_FILE_NAME)
    modelData = compileInputData(EXCEL_WB)
    
    # Close Excel input file
    EXCEL_WB.close()
    
    return modelData


def compileModelData(WS):
    modelData.Name = WS.Main['Model Name'][0]
    
    modelData.Population = {}
    modelData.Stops = {}
    modelData.Shelters = {}
    modelData.Routes = {}
    modelData.Buses = {}
    modelData.Polygons = {}
    
    ExcelTab = WS.Population
    for k in ExcelTab.keys():
        object_population = Population(ExcelTab[k])
        modelData.Population[k] = object_population
        
    ExcelTab = WS.Stops
    for k in ExcelTab.keys():
        object_busstop = BusStop(ExcelTab[k])
        modelData.Stops[k] = object_busstop
    
    ExcelTab = WS.Shelters
    for k in ExcelTab.keys():
        object_shelter = Shelter(ExcelTab[k])
        modelData.Shelters[k] = object_shelter
        
    ExcelTab = WS.Routes
    for k in ExcelTab.keys():
        object_route = Route(ExcelTab[k])
        modelData.Routes[k] = object_route
    
    ExcelTab = WS.Buses
    for k in ExcelTab.keys():
        object_bus = Bus(ExcelTab[k])
        modelData.Buses[k] = object_bus
        
    ExcelTab = WS.Polygons
    for k in ExcelTab.keys():
        object_polygons = Polygon(ExcelTab[k])
        modelData.Polygons[k] = object_polygons
        
    return modelData



def ParseWorkbook(EXCEL_WB):
    WS.Main = CleanData(EXCEL_WB, 'Main', 'Parameter')
    WS.Population = CleanData(EXCEL_WB, 'Population', 'ID')
    WS.Stops = CleanData(EXCEL_WB, 'Stops', 'ID')
    WS.Shelters = CleanData(EXCEL_WB, 'Shelters', 'ID')
    WS.Routes = CleanData(EXCEL_WB, 'Routes', 'ID')
    WS.Buses = CleanData(EXCEL_WB, 'Buses', 'ID')
    WS.Polygons = CleanData(EXCEL_WB, 'Polygons', 'ID')

    return WS



def CleanData(WB, WS_name, head_name, bZero=False):
    
    WS_data = WB.parse(WS_name, keep_default_na = False)
    if head_name == '':
        df_temp = WS_data.T.to_dict('list')
    elif head_name == 'get_headers':
        df_temp = WS_data.head(0).columns
    else:
        df_temp = WS_data.set_index(head_name).T.to_dict('list')
        
    df = {}
    if head_name == 'get_headers':
        df = df_temp
    else:
        for k in df_temp.keys():
            all_blank = True
            for y in range(0,len(df_temp[k])):
                if isinstance(df_temp[k][y], str):
                    df_temp[k][y] = df_temp[k][y].strip(' ')
                    if df_temp[k][y] != '':
                        all_blank = False
                if bZero:
                    all_blank = False
                    if df_temp[k][y] == '':
                        df_temp[k][y] = 0
            if not all_blank:
                df[k] = df_temp[k]
                
    return df

