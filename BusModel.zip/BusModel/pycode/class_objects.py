# -*- coding: utf-8 -*-
"""
Created on Wed Mar 30 20:51:05 2022

@author: GMU
"""

class WS:
    def __init__(self, s):
        self.Main = s[0]
        self.Population = s[1]
        self.Stops = s[2]
        self.Shelters = s[3]
        self.Routes = s[4]
        self.Buses = s[5]
        self.Polygons = s[6]
        
        
class modelData:
    def __init__(self, d):
        self.Name = d[0]
        self.Population = d[1]
        self.Stops = d[2]
        self.Shelters = d[3]
        self.Routes = d[4]
        self.Buses= d[5]
        self.Polygons = d[6]
        
class modelOutputs:
    def __init__(self, i):
        self.ActivityLog = i[0]
        self.AgentWaitTimes = i[1]
        self.SimulationEndTime = i[2]
        self.SimulationMaxTime = i[3]
        self.ShelteredAgentsAll = i[4]
        self.ShelteredAgentsEach = i[5]
        self.BusAssignmentList = i[6]
        self.BusShelterList = i[7]
        self.DistanceDemand = i[8]
        self.AgentWaitTimesVsTime = i[9]
        self.PackingTimes = i[10]
        self.PercentageEvacuatedTime = i[11]
        self.ShelterArrivalTime = i[12]
        self.BusDwellTime = i[13]
        self.RecordTransitTimes = i[14]
        
class modelParameters:
    def __init__(self, p):
        self.distance_matrix = p[0]
        self.BUS = p[1]
        self.BUSROUTES = p[2]
        self.ASSIGNMENTS = p[3]
        self.dictWalkTimes = p[4]
        self.walkroute_matrix = p[5]
        self.BUSTRIPS = p[6]
        self.ADJUSTED_CAPACITY = p[7]
        self.TRANSFERROUTES = p[8]
        
class Inputs:
    def __init__(self, i):
        self.INPUT_FILE_NAME = i[0]
        self.INPUT_DIRECTORY = i[1]
        self.OUTPUT_DIRECTORY = i[2]
        self.SIMULATION_TIME = i[3]
        self.PERCENTAGE_POPULATION_TO_SHELTER = i[4]
        self.TIME_PER_WHEELCHAIR_LOAD = i[5]
        self.ZONES_TO_EVACUATE = i[6]
        self.NEIGHBORHOOD_ROUTE_COLOR = i[7]
        self.BUS_ROUTE_COLOR = i[8]
        self.THRESHOLD_RADIUS_BUS_STOP = i[9]
        self.BUS_CAPACITY = i[10]
        self.PEOPLE_PER_AGENT = i[11]
        self.ADJUSTED_BUS_CAPACITY = i[12]
        self.TIME_PER_AGENT_LOAD_BUS = i[13]
        self.NUMBER_OF_EXPERIMENTS = i[14]
        self.TIERED_EVACUATION = i[15]
        self.SELECT_NODES_TO_EVACUATE = i[16]
        self.ARRIVAL_WINDOW = i[17]
        self.BUS_MIN_INTERVAL = i[18]
        self.BUS_MAX_INTERVAL = i[19]
        self.MIN_NUMBER_BUSES = i[20]
        self.MAX_NUMBER_BUSES = i[21]
        self.SOLVE_METHOD = i[22]
        self.PERCENT_IN_WHEELCHAIR = i[23]
        
        
        
class Shelter:
    def __init__(self, s):
        self.Name = s[0]
        self.Address = s[1]
        self.Latitude = s[2]
        self.Longitude = s[3]
        self.Capacity = s[4]
        self.Tier = s[5]
        self.Zone = s[6]
        
class BusStop:
    def __init__(self, b):
        self.Name = b[0]
        self.Address = b[1]
        self.Latitude = b[2]
        self.Longitude = b[3]
        self.Capacity = b[4]
        self.Zone = b[5]
        self.Active = b[6]
        
class Population:
    def __init__(self, p):
        self.Name = p[0]
        self.Address = p[1]
        self.Latitude = p[2]
        self.Longitude = p[3]
        self.NumPeople = p[4]
        self.Zone = p[5]
        
#class Route:
#    def __init__(self, r):
#        self.Name = r[0]
#        self.Origin = r[1]
#        self.Destination = r[2]
#        self.RouteID = r[3]
#        self.Activity = r[4]
        
class Bus:
    def __init__(self, b):
        self.Name = b[0]
        self.Route = b[1]
        self.Capacity = b[2]
        
class Trip:
    def __init__(self, t):
        self.ID = t[0]
        self.Route = t[1]
        self.Order = t[2]
        
class Route:
    def __init__(self, r):
        self.ID = r[0]
        self.Nodes = r[1]
        self.Lengths = r[2]
        
class Transfer:
    def __init__(self, tr):
        self.ID = tr[0]
        self.Nodes = tr[1]
        self.Length = tr[2]

class Polygon:
    def __init__(self, p):
        self.Zone = p[0]
        self.Color = p[1]
        self.Coordinates = p[2]
        
        
        
        
        