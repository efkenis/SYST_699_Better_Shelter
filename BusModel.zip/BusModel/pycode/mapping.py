# -*- coding: utf-8 -*-
"""
Created on Fri Apr  1 10:58:29 2022

@author: Developer
"""
import folium
from osmnx import graph_from_place, add_edge_speeds, add_edge_travel_times
from osmnx import utils_geo, plot_graph_routes, speed, plot_graph, config
from osmnx import graph_to_gdfs, geometries_from_place, plot_route_folium
from warnings import filterwarnings
#from gdal import VectorTranslateOptions

def InitializeMap():
    
    filterwarnings('ignore')
    print('...Loading Virginia Beach street map')
    
    # Read OpenStreetMap data
    G = graph_from_place('Virginia Beach, VA, USA', network_type='drive')
    
    # impute speed on all edges missing data
    G = add_edge_speeds(G)
    # calculate travel time (seconds) for all edges
    G = add_edge_travel_times(G)
    hwy_speeds = {"residential": 35, "secondary": 50, "tertiary": 60}
    G = add_edge_speeds(G, hwy_speeds)
    G = add_edge_travel_times(G)
    
    return G


def displayMap(G, cnfg, modelData, modelParameters, route_list, level_detail):
    
    #config(use_cache=True, log_console=False)
    
    
    lats = []
    lons = []
    for p in modelData.Population.keys():
        lats.append(modelData.Population[p].Latitude)
        lons.append(modelData.Population[p].Longitude)
    
    minlat = min(lats)
    minlon = min(lons)
    maxlat = max(lats)
    maxlon = max(lons)
    # center map
    coords_lat = 36.746149938805814
    coords_lon = -76.0576351425146
   # bbox = utils_geo.bbox_from_point((coords_lat, coords_lon), dist=22000)
    #fig, ax = plot_graph_routes(G, route_list, 
    #                               route_colors=route_colors,
    #                               node_size=0, 
    #                               bbox=bbox, 
    #                               bgcolor='w', 
    #                               show=False, 
    #                               close=False)
    
    route_map = folium.Map(location=[coords_lat,coords_lon])
    
    ocean = '#668abe'
    blue = '#2f00ff'
    seaweed = '#79cfb8'
    sky = '#89cff0'
    black = '#222222'
    brick = '#d54240'
    purple = '#cc66aa'
    lightred = '#fd6159'
    medgreen = '#0d8767'
    
    brick = '#b71c1c'
    magenta = '#880e4f'
    darkblue = '#1a237e'
    medblue = '#0d47a1'
    seagreen = '#004d40'
    medgreen = '#1b5e20'
    orange = '#ff6f00'
    turqoise = '#00b8d4'
    purple = '#6a1b9a'
    
    palette = [brick, darkblue, seagreen, orange, purple, magenta, 
               medblue, medgreen, turqoise, seaweed, ocean ]
    selectC = 0
    
    if len(route_list.keys()) > 0:
        color_by_route = {}
        for k in route_list.keys():
            if k not in modelData.Population.keys():
                busrouteID = k.split('_')[3]
                if busrouteID not in color_by_route.keys():
                    color_by_route[busrouteID] = palette[selectC]
                    selectC += 1
                    if selectC >= len(palette):
                        selectC = 0
                    
        if level_detail == 'bus routes':
            route_colors = {}
            #used_bus_route_list = [b[2] for b in modelParameters.BUS.values()]
            for r in route_list.keys():
                if r in modelData.Population.keys():
                    route_colors[r] = cnfg.NEIGHBORHOOD_ROUTE_COLOR
                else:
                    busrouteID = r.split('_')[3]
                    route_colors[r] = color_by_route[busrouteID] #cnfg.BUS_ROUTE_COLOR
             
                '''
        for p in modelData.Polygons.keys():
            polyCoords = modelData.Polygons[p].Coordinates
            polyCoords = eval(polyCoords)
            polyColor = modelData.Polygons[p].Color
            polyZone = modelData.Polygons[p].Zone
            if polyZone in cnfg.ZONES_TO_EVACUATE:
                folium.Polygon(polyCoords,
                               color = polyColor,
                               weight = 2,
                               fill = True,
                               fill_color = polyColor,
                               fill_opacity = 0.2,
                               tooltip=p).add_to(route_map)
                '''
            
        for n in modelData.Population.keys():
            if len(route_list[n]) > 1:
                route_map = plot_route_folium(G, route_list[n], route_map=route_map,
                                              route_width=3,
                                            route_color=route_colors[n],
                                            opacity = 1,
                                            titles='openstreetmap',
                                            popup_attribute='name')
        for r in route_list.keys():
            if r not in modelData.Population.keys():
                route_id = r
                if len(route_list[route_id]) > 1:
                    route_map = plot_route_folium(G, route_list[route_id], route_map=route_map,
                                                  route_width=3,
                                                route_color=route_colors[route_id],
                                                opacity = 1,
                                                titles='openstreetmap',
                                                popup_attribute='name')
            
        #marker_cluster = folium.MarkerCluster().add_to(route_map)
    
        #for point in range(0, len(pop_list)):
        #    folium.Marker(pop_list[point], popup=df_counters['Name'][point]).add_to(marker_cluster)
        
        #map = folium.Map(location=[38.9, -77.05], zoom_start=12)
        #for point in range(0, len(pop_list)):
        #    folium.Marker(pop_list[point], popup='name').add_to(route_map)
    
    list_of_shelters = []
    
    if level_detail == 'bus routes':
        for b in modelParameters.BUS.keys():
            if not modelParameters.BUS[b][0] in list_of_shelters:
                list_of_shelters.append(modelParameters.BUS[b][0])
    else:
        for sh in modelData.Shelters.keys():
            list_of_shelters.append(sh)
    
    for k in modelData.Shelters.keys():
        lat = modelData.Shelters[k].Latitude
        lon = modelData.Shelters[k].Longitude   
        name = modelData.Shelters[k].Name
        capacity = modelData.Shelters[k].Capacity
        
        
        if cnfg.TIERED_EVACUATION == True:
            tier = modelData.Shelters[k].Tier
            msg = 'Tier %s - %s' % (tier, name) 
            msg = msg + ' (capacity: %d)' % (capacity)
        else:
            tier = 0
            msg = '%s' % (name) 
            msg = msg + ' (capacity: %d)' % (capacity)
        if k in list_of_shelters:
            icon=folium.Icon(color='purple', icon_color='white', 
                             icon='fa-solid fa-building', angle=0, 
                             prefix='fa')
            folium.Marker([lat,lon], icon=icon,
            tooltip=msg).add_to(route_map)
        else:
            icon=folium.Icon(color='lightgray', icon_color='white', 
                             icon='fa-solid fa-building', angle=0, 
                             prefix='fa')
            folium.Marker([lat,lon],
                          icon=icon,
                          tooltip=msg).add_to(route_map)
    
    for k in modelData.Population.keys():
        lat = modelData.Population[k].Latitude
        lon = modelData.Population[k].Longitude   
        name = modelData.Population[k].Name
        pickup_requests = modelData.Population[k].NumPeople
        zone = modelData.Population[k].Zone
        individuals = pickup_requests * cnfg.PEOPLE_PER_AGENT
        #icon=folium.Icon(color='darkred', icon_color='white', 
        #                 icon='male', angle=0, prefix='fa')
        #folium.Marker([lat,lon], popup=name, icon=icon).add_to(route_map)
        msg = "Zone %s - %s - Pickup requests: %d (%d individuals)" % (zone, name, pickup_requests, individuals)
        
        if len(cnfg.SELECT_NODES_TO_EVACUATE) > 0:
            Z = cnfg.SELECT_NODES_TO_EVACUATE
        else:
            Z = cnfg.ZONES_TO_EVACUATE
        
        if zone in Z or k in Z:
            folium.Circle(location=[lat, lon],
                  radius=10*pickup_requests,
                  opacity = 0.8,
                  fill_opacity = 0.8,
                  color = 'red',
                  fill=True,
                  tooltip=msg,
                  ).add_to(route_map)
        else:
            folium.Circle(location=[lat, lon],
                  radius=10*pickup_requests,
                  opacity = 0.5,
                  fill_opacity = 0.5,
                  color = 'lightgray',
                  fill=True,
                  tooltip=msg,
                  ).add_to(route_map)
    
    if level_detail == 'bus routes':
        list_of_stops = modelData.Stops
    else:
        list_of_stops = modelData.Population
        
    for k in list_of_stops.keys():
        lat = list_of_stops[k].Latitude
        lon = list_of_stops[k].Longitude   
        name = list_of_stops[k].Name
        if level_detail == 'bus routes':
            inservice = modelParameters.ASSIGNMENTS[k]
        else:
            inservice = [1]
        if len(inservice) > 0: # bus stop in service
            msg = "Bus Stop: %s" % (name)
            icon=folium.Icon(color='darkblue', icon_color='white', 
                             icon='fa-solid fa-bus', angle=0, prefix='fa')
            folium.Marker([lat,lon], tooltip=msg, icon=icon).add_to(route_map)
        else:
            msg = "Not in service: %s" % (name)
            #icon=folium.Icon(color='lightgray', icon_color='white', 
            #                 icon='fa-solid fa-bus', angle=0, prefix='fa')
            
            #folium.Marker([lat,lon], tooltip=msg, icon=icon).add_to(route_map)
            
    
    
    #route_map
    route_map.fit_bounds([[minlat,maxlon],[maxlat,minlon]])


    #ax.scatter(coords_lon, coords_lat, c='red')
    
    
    #fig, ax = plot_graph(G, edge_linewidth=3, node_size=0, show=False, close=False)
    #for _, edge in graph_to_gdfs(G, nodes=False).fillna('').iterrows():
    #    text = edge['name']
    #    c = edge['geometry'].centroid
    #    ax.annotate(text, (c.x, c.y), c='w')

    
    #times = speed.add_edge_travel_times(G, precision=1)

    #route_map.show()
    

    route_map.save(cnfg.OUTPUT_DIRECTORY + '/route_map.html')



### Filter population nodes according to flood zones, i.e. which zones evacuate
def filterByZone(modelConfig, modelData):
    
    listZones = ''
    numZones = len(modelConfig.ZONES_TO_EVACUATE)
    if numZones == 1:
        listZones = modelConfig.ZONES_TO_EVACUATE[0]
        print('...Filter by zone ' + str(listZones))
    elif numZones > 1:
        for z in modelConfig.ZONES_TO_EVACUATE:
            listZones = str(z)
            listZones = str(listZones) + ', '
        print('...Filter by zones ' + str(listZones))
    
    inputDict = modelData.Population
    outputDict = {}
    
    if len(modelConfig.SELECT_NODES_TO_EVACUATE) > 0:
        Z = modelConfig.SELECT_NODES_TO_EVACUATE
        for k in inputDict.keys():
            if k in Z:
                outputDict[k] = inputDict[k]
    else:
        Z = modelConfig.ZONES_TO_EVACUATE
        if numZones > 0:
            for k in inputDict.keys():
                if inputDict[k].Zone in Z:
                    outputDict[k] = inputDict[k]
    
    return outputDict
    

### Scale population in terms of percentage of total that will go to shelter
def scalePopulation(modelConfig, modelData):
    
    percent = modelConfig.PERCENTAGE_POPULATION_TO_SHELTER
    
    if percent < 1:
        print('...Scaling population to ' + str(percent * 100) + '%')
    
    inputDict = modelData.Population
    outputDict = inputDict
    for k in inputDict.keys():
        orig_population = inputDict[k].NumPeople
        outputDict[k].NumPeople = int(round(percent * orig_population))
        
    return outputDict


#def shapefile2geojson(infile, outfile, fieldname):
#    '''Translate a shapefile to GEOJSON.'''
#    options = gdal.VectorTranslateOptions(format="GeoJSON",
#                                          dstSRS="EPSG:4326")
#    gdal.VectorTranslate(outfile, infile, options=options)


